﻿# HTTP и WebSocket сервер на Boost.Asio/Beast

Этот документ - учебная карта для самостоятельной реализации двух вещей на общей серверной базе:

```text
1. HTTP server
2. WebSocket server
```

Цель - получить понимание и практический опыт работы с обоими протоколами. Код проекта сейчас менять не нужно: документ объясняет архитектуру, синтаксис и порядок реализации.

## 1. Общая идея

HTTP и WebSocket можно построить на одном TCP-сервере.

Сначала клиент всегда подключается как обычный TCP client. Затем он отправляет HTTP request.

Дальше возможны два пути:

```text
Обычный HTTP request
  -> обработать через HTTP Session
  -> вернуть HTTP response

WebSocket Upgrade request
  -> принять upgrade
  -> передать socket в WebSocket Session
  -> дальше читать/писать WebSocket messages
```

Общая схема:

```text
Server
  -> io_context
  -> thread pool
  -> Listener

Listener
  -> async_accept()
  -> DetectSession

DetectSession
  -> async_read first HTTP request
  -> if websocket upgrade: WebSocketSession
  -> else: HttpSession

HttpSession
  -> RequestDispatcher
  -> AppRouter
  -> HttpResponse

WebSocketSession
  -> websocket accept
  -> async_read message loop
  -> async_write messages
```

Почему нужен `DetectSession`: WebSocket начинается с HTTP upgrade request. Чтобы понять, обычный это HTTP request или WebSocket, нужно сначала прочитать HTTP headers.

## 2. Что есть сейчас

Текущий сервер в проекте - синхронный HTTP server:

```cpp
asio::io_context io;
tcp::acceptor acceptor{io, {tcp::v4(), port}};
RequestDispatcher dispatcher{router_};

for (;;) {
  tcp::socket socket{io};
  acceptor.accept(socket);

  boost::beast::flat_buffer buffer;
  BeastRequest request;
  http::read(socket, buffer, request);

  BeastResponse response = dispatcher.dispatch(request);
  http::write(socket, response);
}
```

Синтаксис:

```cpp
asio::io_context io;
```

`io_context` - очередь событий Boost.Asio. В многопоточном async-сервере несколько worker threads вызывают `io.run()` и исполняют готовые callbacks.

```cpp
tcp::acceptor acceptor{io, {tcp::v4(), port}};
```

`acceptor` слушает TCP port.

```cpp
acceptor.accept(socket);
http::read(socket, buffer, request);
http::write(socket, response);
```

Это blocking-вызовы. Их нужно заменить на:

```text
async_accept
async_read
async_write
```

## 3. Общий фундамент: thread pool

И HTTP, и WebSocket должны работать на одном `io_context`.

Типичная структура:

```cpp
asio::io_context io;

std::vector<std::thread> threads;
threads.reserve(thread_count);

for (std::size_t i = 0; i < thread_count; ++i) {
  threads.emplace_back([&io] {
    io.run();
  });
}

for (auto& thread : threads) {
  thread.join();
}
```

Разбор синтаксиса:

```cpp
std::vector<std::thread> threads;
```

Хранилище worker threads.

```cpp
threads.emplace_back([&io] { io.run(); });
```

`emplace_back` создает новый `std::thread`. Lambda захватывает `io` по ссылке: `[&io]`.

```cpp
io.run();
```

Поток начинает выполнять callbacks, которые появляются после завершения async operations.

```cpp
thread.join();
```

Главный поток ждет завершения worker-а.

Практическое правило:

```text
thread_count = std::thread::hardware_concurrency()
если вернул 0, использовать 1
```

## 4. Общий Listener

`Listener` принимает TCP connections. Он не знает, будет это HTTP или WebSocket.

Идея класса:

```cpp
class Listener : public std::enable_shared_from_this<Listener> {
public:
  using tcp = boost::asio::ip::tcp;

  Listener(boost::asio::io_context& io, tcp::endpoint endpoint, AppRouter& router);

  void run();

private:
  void doAccept();
  void onAccept(boost::system::error_code ec, tcp::socket socket);

  boost::asio::io_context& io_;
  tcp::acceptor acceptor_;
  AppRouter& router_;
};
```

### `enable_shared_from_this`

```cpp
class Listener : public std::enable_shared_from_this<Listener>
```

Этот базовый класс дает метод:

```cpp
shared_from_this()
```

Он нужен, чтобы объект жил до завершения async callback-а.

Неправильно:

```cpp
[this] {
  onAccept(...);
}
```

`this` не продлевает жизнь объекта.

Правильно:

```cpp
[self = shared_from_this()] {
  self->onAccept(...);
}
```

`self` - это `std::shared_ptr<Listener>`. Пока callback жив, Listener тоже жив.

### async_accept

```cpp
void Listener::doAccept() {
  acceptor_.async_accept(
      boost::asio::make_strand(io_),
      [self = shared_from_this()](boost::system::error_code ec, tcp::socket socket) {
        self->onAccept(ec, std::move(socket));
      });
}
```

Синтаксис:

```cpp
acceptor_.async_accept(...)
```

Запускает асинхронный accept и сразу возвращает управление.

```cpp
boost::asio::make_strand(io_)
```

Создает strand executor. Socket, принятый через этот executor, будет связан со strand.

`strand` гарантирует:

```text
callbacks одного соединения не выполняются одновременно в разных потоках
```

```cpp
std::move(socket)
```

Socket нельзя копировать, только перемещать. `std::move` передает владение дальше.

### onAccept

```cpp
void Listener::onAccept(boost::system::error_code ec, tcp::socket socket) {
  if (!ec) {
    std::make_shared<DetectSession>(std::move(socket), router_)->run();
  }

  doAccept();
}
```

Разбор:

```cpp
if (!ec)
```

`error_code` приводится к bool: если ошибки нет, `!ec` true.

```cpp
std::make_shared<DetectSession>(...)
```

Создает session-объект в heap под управлением `shared_ptr`.

```cpp
doAccept();
```

Сразу запускает прием следующего клиента. Важно: обработка одного клиента не должна блокировать accept новых.

## 5. Почему нужен DetectSession

WebSocket начинается как HTTP request:

```http
GET /ws HTTP/1.1
Host: localhost:8080
Upgrade: websocket
Connection: Upgrade
Sec-WebSocket-Key: ...
Sec-WebSocket-Version: 13
```

Обычный HTTP request может быть:

```http
GET /health HTTP/1.1
Host: localhost:8080
```

Нужно прочитать первый HTTP request и проверить:

```cpp
websocket::is_upgrade(request_)
```

Если true - это WebSocket.

Если false - обычный HTTP.

## 6. DetectSession: структура

Пример идеи:

```cpp
class DetectSession : public std::enable_shared_from_this<DetectSession> {
public:
  explicit DetectSession(tcp::socket socket, AppRouter& router);

  void run();

private:
  void doRead();
  void onRead(boost::system::error_code ec, std::size_t bytes);

  boost::beast::tcp_stream stream_;
  boost::beast::flat_buffer buffer_;
  BeastRequest request_;
  AppRouter& router_;
};
```

### Почему `tcp_stream`, а не `tcp::socket`

```cpp
boost::beast::tcp_stream stream_;
```

`tcp_stream` - Beast-обертка над socket. Она удобна для timeout:

```cpp
stream_.expires_after(std::chrono::seconds(30));
```

### Конструктор

```cpp
DetectSession::DetectSession(tcp::socket socket, AppRouter& router)
    : stream_(std::move(socket)), router_(router) {}
```

Синтаксис:

```cpp
: stream_(std::move(socket)), router_(router)
```

Это initializer list. Поля класса инициализируются до тела конструктора.

`std::move(socket)` передает владение socket-ом в `stream_`.

### Чтение первого request

```cpp
void DetectSession::doRead() {
  stream_.expires_after(std::chrono::seconds(30));

  http::async_read(
      stream_,
      buffer_,
      request_,
      [self = shared_from_this()](boost::system::error_code ec, std::size_t bytes) {
        self->onRead(ec, bytes);
      });
}
```

Аргументы `http::async_read`:

```text
stream_
  откуда читать bytes

buffer_
  промежуточный буфер Beast

request_
  куда Beast положит HTTP request

callback
  что вызвать после завершения чтения
```

`buffer_` должен жить дольше операции, поэтому это поле класса.

## 7. Ветка выбора HTTP или WebSocket

```cpp
void DetectSession::onRead(boost::system::error_code ec, std::size_t) {
  if (ec) {
    return fail(ec, "detect read");
  }

  if (websocket::is_upgrade(request_)) {
    std::make_shared<WebSocketSession>(
        stream_.release_socket(),
        router_,
        std::move(request_))
        ->run();
    return;
  }

  std::make_shared<HttpSession>(
      std::move(stream_),
      std::move(buffer_),
      std::move(request_),
      router_)
      ->run();
}
```

Разберем.

```cpp
websocket::is_upgrade(request_)
```

Проверяет HTTP headers и method. Возвращает true, если request просит WebSocket upgrade.

```cpp
stream_.release_socket()
```

Достает socket из `tcp_stream`. Это нужно, если `WebSocketSession` хочет создать:

```cpp
websocket::stream<tcp::socket>
```

Альтернативно можно делать:

```cpp
websocket::stream<boost::beast::tcp_stream>
```

Тогда socket можно не release-ить. Для учебного проекта вариант с `tcp_stream` внутри websocket тоже хорош.

```cpp
std::move(request_)
```

Передает уже прочитанный HTTP request в следующую session. Это важно: WebSocket accept должен использовать тот самый upgrade request, который мы уже прочитали.

```cpp
std::move(buffer_)
```

Если обычный HTTP request уже прочитан, `HttpSession` может получить buffer и request, чтобы сразу dispatch-нуть первый request, а потом читать следующие keep-alive request-ы.

## 8. HTTP Session

HTTP Session обслуживает обычные HTTP requests.

Ее задачи:

```text
1. Получить первый request от DetectSession.
2. Отдать его в RequestDispatcher.
3. async_write response.
4. Если keep-alive включен, читать следующий request.
5. Если соединение закрывается, shutdown socket.
```

Структура:

```cpp
class HttpSession : public std::enable_shared_from_this<HttpSession> {
public:
  HttpSession(
      boost::beast::tcp_stream stream,
      boost::beast::flat_buffer buffer,
      BeastRequest request,
      AppRouter& router);

  void run();

private:
  void handleRequest();
  void doRead();
  void onRead(boost::system::error_code ec, std::size_t bytes);
  void doWrite();
  void onWrite(bool close, boost::system::error_code ec, std::size_t bytes);
  void doClose();

  boost::beast::tcp_stream stream_;
  boost::beast::flat_buffer buffer_;
  BeastRequest request_;
  std::shared_ptr<BeastResponse> response_;
  RequestDispatcher dispatcher_;
};
```

### Почему `stream` принимается по значению

```cpp
HttpSession(boost::beast::tcp_stream stream, ...)
```

`tcp_stream` нельзя копировать, но можно перемещать. Принимая по значению и делая `std::move`, мы явно передаем владение session-объекту.

```cpp
: stream_(std::move(stream))
```

### Первый request

`DetectSession` уже прочитал первый request. Поэтому `HttpSession::run()` может сразу вызвать:

```cpp
void HttpSession::run() {
  handleRequest();
}
```

А не `doRead()`.

### Dispatch

```cpp
void HttpSession::handleRequest() {
  response_ = std::make_shared<BeastResponse>(dispatcher_.dispatch(request_));
  doWrite();
}
```

Почему `shared_ptr`:

```text
async_write должен видеть response до завершения write.
Локальная переменная уничтожилась бы слишком рано.
```

### Write

```cpp
void HttpSession::doWrite() {
  const bool close = response_->need_eof();

  http::async_write(
      stream_,
      *response_,
      [self = shared_from_this(), close](boost::system::error_code ec, std::size_t bytes) {
        self->onWrite(close, ec, bytes);
      });
}
```

`response_->need_eof()` означает: после ответа соединение надо закрыть.

`[self = shared_from_this(), close]` захватывает:

```text
self
  продлевает жизнь HttpSession

close
  копия bool, нужна в callback
```

### Keep-alive

```cpp
void HttpSession::onWrite(bool close, boost::system::error_code ec, std::size_t) {
  if (ec) {
    return fail(ec, "http write");
  }

  response_ = nullptr;

  if (close) {
    return doClose();
  }

  doRead();
}
```

Если соединение остается открытым, читаем следующий request.

```cpp
void HttpSession::doRead() {
  request_ = {};
  stream_.expires_after(std::chrono::seconds(30));

  http::async_read(
      stream_,
      buffer_,
      request_,
      [self = shared_from_this()](boost::system::error_code ec, std::size_t bytes) {
        self->onRead(ec, bytes);
      });
}
```

`request_ = {};` очищает старый request.

## 9. WebSocket Session

WebSocket Session обслуживает уже не HTTP requests, а WebSocket messages.

После upgrade connection становится двусторонним message stream:

```text
client -> message -> server
server -> message -> client
```

Структура:

```cpp
class WebSocketSession : public std::enable_shared_from_this<WebSocketSession> {
public:
  WebSocketSession(tcp::socket socket, BeastRequest request);

  void run();

private:
  void onAccept(boost::system::error_code ec);
  void doRead();
  void onRead(boost::system::error_code ec, std::size_t bytes);
  void doWrite(std::string message);
  void onWrite(boost::system::error_code ec, std::size_t bytes);

  boost::beast::websocket::stream<tcp::socket> ws_;
  boost::beast::flat_buffer buffer_;
  BeastRequest request_;
};
```

### WebSocket stream

```cpp
boost::beast::websocket::stream<tcp::socket> ws_;
```

Это Beast-обертка, которая понимает WebSocket frames.

Можно читать:

```cpp
ws_.async_read(buffer_, callback);
```

Можно писать:

```cpp
ws_.async_write(buffer, callback);
```

### Accept upgrade

```cpp
void WebSocketSession::run() {
  ws_.set_option(websocket::stream_base::timeout::suggested(boost::beast::role_type::server));

  ws_.async_accept(
      request_,
      [self = shared_from_this()](boost::system::error_code ec) {
        self->onAccept(ec);
      });
}
```

Разбор:

```cpp
ws_.set_option(...)
```

Настраивает WebSocket stream.

```cpp
websocket::stream_base::timeout::suggested(...)
```

Beast дает рекомендуемые timeout-настройки для роли client/server.

```cpp
boost::beast::role_type::server
```

Говорит: этот stream работает на стороне сервера.

```cpp
ws_.async_accept(request_, callback)
```

Принимает WebSocket upgrade на основе HTTP request, который уже был прочитан в `DetectSession`.

Если accept успешен, соединение стало WebSocket.

### Read loop

```cpp
void WebSocketSession::onAccept(boost::system::error_code ec) {
  if (ec) {
    return fail(ec, "websocket accept");
  }

  doRead();
}
```

После успешного accept запускаем чтение сообщений.

```cpp
void WebSocketSession::doRead() {
  buffer_.clear();

  ws_.async_read(
      buffer_,
      [self = shared_from_this()](boost::system::error_code ec, std::size_t bytes) {
        self->onRead(ec, bytes);
      });
}
```

`buffer_.clear()` очищает старое сообщение.

`ws_.async_read` читает одно WebSocket message, а не один произвольный кусок TCP bytes.

### Получить текст сообщения

```cpp
auto message = boost::beast::buffers_to_string(buffer_.data());
```

Разбор:

```cpp
buffer_.data()
```

Возвращает sequence of buffers.

```cpp
buffers_to_string(...)
```

Копирует содержимое buffer-ов в `std::string`.

### Echo example

Для учебного старта можно сделать echo-server:

```cpp
void WebSocketSession::onRead(boost::system::error_code ec, std::size_t) {
  if (ec == websocket::error::closed) {
    return;
  }

  if (ec) {
    return fail(ec, "websocket read");
  }

  auto message = boost::beast::buffers_to_string(buffer_.data());
  doWrite(std::move(message));
}
```

Если клиент закрыл WebSocket:

```cpp
ec == websocket::error::closed
```

Это нормальное завершение, не ошибка.

### Write message

```cpp
void WebSocketSession::doWrite(std::string message) {
  auto response = std::make_shared<std::string>(std::move(message));

  ws_.text(true);

  ws_.async_write(
      boost::asio::buffer(*response),
      [self = shared_from_this(), response](boost::system::error_code ec, std::size_t bytes) {
        self->onWrite(ec, bytes);
      });
}
```

Разбор:

```cpp
auto response = std::make_shared<std::string>(std::move(message));
```

Message должен жить до завершения `async_write`. Поэтому кладем строку в `shared_ptr`.

```cpp
ws_.text(true);
```

Говорит WebSocket stream отправлять text frame. Для binary:

```cpp
ws_.binary(true);
```

```cpp
boost::asio::buffer(*response)
```

Создает buffer view поверх строки. Важно: buffer не владеет памятью, поэтому строка должна жить до конца async_write.

```cpp
[self = shared_from_this(), response]
```

Захватываем `response`, чтобы строка не уничтожилась до конца записи.

После write:

```cpp
void WebSocketSession::onWrite(boost::system::error_code ec, std::size_t) {
  if (ec) {
    return fail(ec, "websocket write");
  }

  doRead();
}
```

Запускаем чтение следующего сообщения.

## 10. HTTP routes и WebSocket routes

Обычные HTTP routes уже есть:

```cpp
server.get("/health", ...);
server.post("/users", ...);
```

Для WebSocket можно сделать отдельный API:

```cpp
server.websocket("/ws", ...);
```

Но для первого учебного шага можно проще:

```text
Если request target == "/ws" и websocket::is_upgrade(request)
  запускать WebSocketSession
Иначе
  обычный HttpSession
```

Позже можно добавить `WebSocketRouter`.

Пример будущей идеи:

```cpp
class WebSocketRouter {
public:
  using ConnectHandler = std::function<void(WebSocketConnection&)>;
  using MessageHandler = std::function<void(WebSocketConnection&, std::string_view)>;

  void endpoint(std::string path, MessageHandler handler);
};
```

Но не начинай с этого. Сначала сделай один endpoint `/ws` и echo.

## 11. Чем HTTP отличается от WebSocket в коде

HTTP:

```text
request -> response
request -> response
request -> response
```

Каждый request независим. Даже с keep-alive логика остается “прочитал request, отправил response”.

WebSocket:

```text
upgrade once
then messages both directions
```

После upgrade уже нет `HttpRequest` и `HttpResponse`. Есть WebSocket frames/messages.

Отсюда разница классов:

```text
HttpSession
  BeastRequest
  BeastResponse
  RequestDispatcher
  AppRouter

WebSocketSession
  websocket::stream
  flat_buffer
  message handlers
```

## 12. Таймауты

Для HTTP через `tcp_stream`:

```cpp
stream_.expires_after(std::chrono::seconds(30));
```

Для WebSocket:

```cpp
ws_.set_option(websocket::stream_base::timeout::suggested(boost::beast::role_type::server));
```

Можно настроить вручную:

```cpp
websocket::stream_base::timeout option{
    std::chrono::seconds(30),
    std::chrono::seconds(30),
    true};

ws_.set_option(option);
```

Смысл полей:

```text
handshake timeout
  сколько ждать upgrade/handshake

idle timeout
  сколько соединение может молчать

keep_alive_pings
  отправлять ping frames для keep-alive
```

## 13. Body limit для HTTP

Для HTTP request body важно ограничение размера:

```cpp
http::request_parser<http::string_body> parser;
parser.body_limit(1024 * 1024);
```

Синтаксис:

```cpp
http::request_parser<http::string_body>
```

Parser читает HTTP request постепенно и может остановить слишком большой body.

```cpp
parser.body_limit(...)
```

Ставит лимит в байтах.

Для WebSocket нужен похожий лимит на message size:

```cpp
ws_.read_message_max(1024 * 1024);
```

Это ограничит размер одного WebSocket message.

## 14. Потокобезопасность и strand

В многопоточном `io_context` callbacks разных соединений могут выполняться параллельно. Это хорошо.

Но callbacks одного соединения не должны одновременно работать с одним `stream_`, `buffer_`, `request_`.

Поэтому:

```text
1 connection = 1 strand
```

При accept:

```cpp
acceptor_.async_accept(boost::asio::make_strand(io_), ...);
```

Socket будет привязан к strand. Все операции на session stream будут последовательно выполняться для этого соединения.

Для HTTP и WebSocket правило одинаковое.

## 15. Ошибки HTTP и WebSocket

HTTP read:

```text
http::error::end_of_stream
  клиент закрыл соединение

parse error
  вернуть 400

body limit
  вернуть 413
```

WebSocket read:

```text
websocket::error::closed
  клиент нормально закрыл WebSocket

другая ошибка
  логировать и закрыть session
```

Синтаксис проверки:

```cpp
if (ec == websocket::error::closed) {
  return;
}

if (ec) {
  return fail(ec, "websocket read");
}
```

## 16. Жизнь объектов

Самая частая ошибка в async C++ - объект уничтожился, пока операция еще выполняется.

Правила:

```text
Listener живет через shared_ptr.
DetectSession живет через shared_ptr.
HttpSession живет через shared_ptr.
WebSocketSession живет через shared_ptr.
Response/message buffers живут до конца async_write.
```

Поэтому callbacks почти всегда имеют вид:

```cpp
[self = shared_from_this()](boost::system::error_code ec, std::size_t bytes) {
  self->onRead(ec, bytes);
}
```

А для write buffers:

```cpp
[self = shared_from_this(), message](boost::system::error_code ec, std::size_t bytes) {
  self->onWrite(ec, bytes);
}
```

## 17. Порядок реализации

### Шаг 1. Async HTTP без WebSocket

Сделать:

```text
Listener
HttpSession
thread pool
```

Пока без `DetectSession`, если хочешь идти проще.

Цель:

```text
/health и /users работают через async_read/async_write
```

### Шаг 2. Добавить DetectSession

Сделать первый read в `DetectSession`.

Если не WebSocket:

```text
передать stream, buffer, request в HttpSession
```

Цель:

```text
HTTP продолжает работать, но теперь есть точка выбора протокола
```

### Шаг 3. Добавить WebSocketSession

Если request upgrade и path `/ws`:

```text
создать WebSocketSession
async_accept(request)
doRead()
```

Цель:

```text
/ws работает как echo WebSocket endpoint
```

### Шаг 4. Keep-alive для HTTP

После HTTP write:

```text
если close -> close
иначе -> doRead()
```

Цель:

```text
HTTP/1.1 keep-alive работает
```

### Шаг 5. Лимиты и таймауты

Добавить:

```text
HTTP body_limit
WebSocket read_message_max
HTTP operation timeout
WebSocket timeout option
```

Цель:

```text
сервер устойчив к slow client и большим payload
```

### Шаг 6. Graceful shutdown

Добавить:

```cpp
boost::asio::signal_set signals(io, SIGINT, SIGTERM);
```

На сигнал:

```text
закрыть acceptor
остановить io_context
join threads
```

## 18. Что должно остаться в слоях

HTTP и WebSocket infrastructure:

```text
server/core
```

HTTP routing:

```text
AppRouter
RequestDispatcher
```

WebSocket routing:

```text
сначала можно hardcode /ws в DetectSession
позже можно сделать WebSocketRouter
```

Business logic:

```text
controllers/app
```

JSON marshalling:

```text
marshalling
```

Database:

```text
database
persistence
```

Не смешивай:

```text
WebSocketSession не должна знать про ODB.
HttpSession не должна знать про UserController.
Session вызывает RequestDispatcher или WebSocket handler layer.
```

## 19. Проверка

HTTP:

```powershell
curl http://localhost:8080/health
curl -X POST http://localhost:8080/users -H "Content-Type: application/json" -d "{\"name\":\"Alice\"}"
```

WebSocket можно проверить через `websocat`:

```bash
websocat ws://localhost:8080/ws
```

Или через JavaScript в браузере:

```js
const ws = new WebSocket("ws://localhost:8080/ws");

ws.onopen = () => {
  ws.send("hello");
};

ws.onmessage = (event) => {
  console.log(event.data);
};
```

Нагрузка для HTTP:

```bash
wrk -t4 -c100 -d30s http://localhost:8080/health
```

Что проверить:

```text
1. HTTP /health отвечает.
2. HTTP POST /users отвечает.
3. WebSocket /ws принимает upgrade.
4. WebSocket echo возвращает сообщения.
5. Несколько клиентов работают параллельно.
6. Slow client отваливается по timeout.
7. Большие HTTP body получают 413.
8. Большие WebSocket messages закрываются или получают ошибку.
```

## 20. Минимальная цель

Минимальный хороший результат:

```text
Server
  thread pool

Listener
  async_accept

DetectSession
  читает первый HTTP request
  выбирает HTTP или WebSocket

HttpSession
  async HTTP request/response
  keep-alive

WebSocketSession
  async_accept upgrade
  async read/write messages
  echo endpoint /ws

Timeouts and limits
  HTTP timeout
  HTTP body_limit
  WebSocket timeout
  WebSocket message limit
```

После этого у тебя будет опыт и с классическим HTTP request/response, и с WebSocket message loop на одной общей многопоточной Asio/Beast архитектуре.
