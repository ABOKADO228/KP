﻿# Подготовка зависимостей и CMake-сборки сервера

Этот документ подробно описывает, как подготовлены внешние зависимости в проекте `farm_association`, почему они лежат локально в `server/third_party`, как устроена сборка через CMake и зачем были сделаны изменения для одноразовой сборки `libodb` и `libodb-pgsql`.

Главная идея: проект должен собираться воспроизводимо и без глобально установленных C++-пакетов. Поэтому Boost, nlohmann/json, ODB и PostgreSQL client runtime не ищутся в системе, не подтягиваются через vcpkg и не скачиваются на этапе CMake-конфигурации. Все нужное заранее кладется в `server/third_party`, а CMake работает только с этим локальным каталогом.

## Что было сделано в проекте

В проекте была подготовлена локальная схема зависимостей:

```text
server/
  third_party/
    _downloads/
      boost_1_90_0.zip
      nlohmann-json-3.12.0.zip
      odb-2.4.0-i686-windows.zip
      libodb-2.4.0.zip
      libodb-pgsql-2.4.0.zip
      postgresql-18.3-1-windows-x64-binaries.zip
    _sources/
      boost_1_90_0/
      json-3.12.0/
      odb-2.4.0-i686-windows/
      libodb-2.4.0/
      libodb-pgsql-2.4.0/
      pgsql/
    _build/
      odb-local/
    boost/
      include/
      lib/
    nlohmann_json/
      include/
    odb/
      bin/
    libodb/
      include/
      lib/
    libodb-pgsql/
      include/
      lib/
    postgresql/
      include/
      lib/
      bin/
```

Каталог `_downloads` хранит исходные архивы. Это удобно для отчета и для восстановления состояния зависимостей без повторного поиска нужных файлов.

Каталог `_sources` хранит распакованные исходники и бинарные дистрибутивы. Из него CMake берет исходники `libodb` и `libodb-pgsql`.

Каталог `_build` хранит внутренние build-каталоги внешних библиотек. Он нужен, чтобы не смешивать объектные файлы зависимостей с основной сборкой сервера.

Каталоги `boost`, `nlohmann_json`, `odb`, `libodb`, `libodb-pgsql`, `postgresql` являются рабочими install-каталогами. Именно их использует основной `server/CMakeLists.txt`.

## Откуда взяты зависимости

Ниже перечислены зависимости, которые лежат в `server/third_party/_downloads`.

| Зависимость | Локальный архив | Источник |
| --- | --- | --- |
| Boost 1.90.0 | `boost_1_90_0.zip` | официальный релиз Boost: `https://www.boost.org/releases/1.90.0/`, файл также доступен на SourceForge: `https://sourceforge.net/projects/boost/files/boost/1.90.0/boost_1_90_0.zip/` |
| nlohmann/json 3.12.0 | `nlohmann-json-3.12.0.zip` | GitHub-релиз проекта: `https://github.com/nlohmann/json/releases/tag/v3.12.0`, архив исходников: `https://github.com/nlohmann/json/archive/refs/tags/v3.12.0.zip` |
| ODB compiler 2.4.0 for Windows | `odb-2.4.0-i686-windows.zip` | Code Synthesis ODB downloads: `https://www.codesynthesis.com/download/odb/2.4/` |
| libodb 2.4.0 | `libodb-2.4.0.zip` | Code Synthesis ODB downloads: `https://www.codesynthesis.com/download/odb/2.4/` |
| libodb-pgsql 2.4.0 | `libodb-pgsql-2.4.0.zip` | Code Synthesis ODB downloads: `https://www.codesynthesis.com/download/odb/2.4/` |
| PostgreSQL 18.3 Windows x64 binaries | `postgresql-18.3-1-windows-x64-binaries.zip` | EDB PostgreSQL binaries: `https://www.enterprisedb.com/download-postgresql-binaries` |

Локальные SHA256-хэши архивов:

```text
boost_1_90_0.zip
  BDC79F179D1A4A60C10FE764172946D0EEAFAD65E576A8703C4D89D49949973C

nlohmann-json-3.12.0.zip
  34660B5E9A407195D55E8DA705ED26CC6D175CE5A6B1FB957E701FB4D5B04022

odb-2.4.0-i686-windows.zip
  771337A18FA9E5253A7775CC6645A193398B9F7C424B3B631686BBD948C4C499

libodb-2.4.0.zip
  E69CC3E49E511DF2FCEF68BE01C9BEC8DC7D128920978E2D90C739DB95675B0A

libodb-pgsql-2.4.0.zip
  62C82121EFBFA41113CCE0F9F486BD912D994717138B25992B9AC0E3D3A736BD

postgresql-18.3-1-windows-x64-binaries.zip
  4DA1A93CBC69E99936616D53C34466F79E4295FC56134CE4A395E88351213D60
```

## Зачем зависимости лежат локально

Есть несколько причин.

Первая причина - воспроизводимость. Если CMake ищет зависимости через `find_package()` в системе, результат зависит от того, что установлено на конкретном компьютере. На одном компьютере может найтись Boost 1.90.0, на другом Boost 1.84.0, на третьем вообще системного Boost не будет. В учебном проекте это быстро превращается в ошибки, которые трудно объяснять и повторять.

Вторая причина - отсутствие vcpkg. Раньше подобные проекты часто собирают через vcpkg, но здесь поставлена задача собираться без него. Поэтому в CMake явно указано: зависимости находятся внутри `server/third_party`.

Третья причина - ODB 2.4.0 старый. Он нормально используется как runtime-библиотека, но его исходники не рассчитаны на компиляцию как C++20. Поэтому его нужно собирать отдельно, более старым стандартом C++14, а сам сервер можно оставить на C++20.

Четвертая причина - переносимость. В проекте есть слой `FarmLocalDependencies.cmake`, который абстрагирует различия платформ: Windows, Linux, macOS. Там же учитываются разные расширения статических библиотек: на Windows это обычно `.lib`, на Linux/macOS - `.a`.

## Как подготовлен Boost

В проекте используется Boost 1.90.0. Архив:

```text
server/third_party/_downloads/boost_1_90_0.zip
```

Распакованные исходники:

```text
server/third_party/_sources/boost_1_90_0
```

Рабочий install-каталог:

```text
server/third_party/boost
```

Минимально для текущего сервера нужен Boost.Beast. Boost.Beast в основном header-only, но он опирается на Boost.Asio, Boost.System и часть инфраструктуры Boost. Чтобы не ловить ошибки из-за неполного набора заголовков, в `server/third_party/boost/include` положен полный набор Boost-заголовков.

В CMake Boost подключен через interface target `farm_boost`, а не через системный `find_package(Boost)`. Это сделано в функции:

```cmake
farm_add_boost_headers(farm_boost "${FARM_SERVER_DEPS_DIR}")
```

Эта функция проверяет файл:

```text
server/third_party/boost/include/boost/version.hpp
```

Если файла нет, CMake падает с понятной ошибкой. Это лучше, чем получить длинную ошибку компилятора о том, что где-то глубоко не найден `boost/beast/core.hpp`.

Для Boost также добавлены определения:

```cmake
BOOST_ERROR_CODE_HEADER_ONLY
BOOST_SYSTEM_NO_LIB
```

`BOOST_ERROR_CODE_HEADER_ONLY` говорит Boost.System использовать header-only режим для `error_code`, если это возможно.

`BOOST_SYSTEM_NO_LIB` отключает auto-linking на MSVC/Windows. Auto-linking - это механизм, когда Boost сам через pragma пытается подобрать библиотеку для линковки. В переносимой CMake-сборке это нежелательно: CMake должен явно контролировать, что подключается.

## Как подготовлен nlohmann/json

Используется nlohmann/json 3.12.0. Архив:

```text
server/third_party/_downloads/nlohmann-json-3.12.0.zip
```

Распакованные исходники:

```text
server/third_party/_sources/json-3.12.0
```

Рабочий install-каталог:

```text
server/third_party/nlohmann_json
```

Библиотека nlohmann/json является header-only. Для сборки сервера фактически нужен файл:

```text
server/third_party/nlohmann_json/include/nlohmann/json.hpp
```

Поэтому в CMake она подключается простой interface-библиотекой:

```cmake
farm_add_nlohmann_json(farm_nlohmann_json "${FARM_SERVER_DEPS_DIR}")
```

Эта функция проверяет наличие `json.hpp` и добавляет include-директорию в target.

Можно было использовать `find_package(nlohmann_json)`, но в проекте выбран более прямой способ. Он проще и не зависит от того, установлен ли CMake package config `nlohmann_jsonConfig.cmake`.

## Как подготовлен PostgreSQL client runtime

Для работы ODB PostgreSQL нужны заголовки и клиентская библиотека PostgreSQL `libpq`.

Архив:

```text
server/third_party/_downloads/postgresql-18.3-1-windows-x64-binaries.zip
```

Распакованный исходный/бинарный каталог:

```text
server/third_party/_sources/pgsql
```

Рабочий install-каталог:

```text
server/third_party/postgresql
```

Важные файлы:

```text
server/third_party/postgresql/include/libpq-fe.h
server/third_party/postgresql/lib/libpq.a
server/third_party/postgresql/lib/libpq.lib
server/third_party/postgresql/bin/
```

`libpq-fe.h` нужен на этапе компиляции `libodb-pgsql` и серверного кода, который будет работать с PostgreSQL.

`libpq.a` или `libpq.lib` нужны на этапе линковки. Какой файл выберется, зависит от компилятора и платформы. CMake ищет несколько вариантов имени:

```cmake
NAMES pq libpq pq.lib libpq.lib
```

Это сделано, чтобы сборка проходила не только на одном конкретном Windows-наборе инструментов.

## Как подготовлен ODB

ODB состоит не из одной зависимости, а из нескольких частей:

```text
odb compiler
libodb
libodb-pgsql
```

`odb compiler` - это отдельная программа, которая генерирует C++-код по ODB-моделям. В текущем сервере он уже используется при сборке для `server/include/persistence/User.hpp`:

```text
server/third_party/odb/bin/odb.exe
```

Результат генерации складывается не в исходники, а в build-каталог:

```text
server/build/generated/persistence/
  user-odb.cxx
  user-odb.hxx
  user-odb.ixx
  user.sql
```

`libodb` - базовая runtime-библиотека ODB.

`libodb-pgsql` - PostgreSQL-драйвер ODB. Он зависит от `libodb` и от PostgreSQL `libpq`.

Архивы:

```text
server/third_party/_downloads/odb-2.4.0-i686-windows.zip
server/third_party/_downloads/libodb-2.4.0.zip
server/third_party/_downloads/libodb-pgsql-2.4.0.zip
```

Распакованные каталоги:

```text
server/third_party/_sources/odb-2.4.0-i686-windows
server/third_party/_sources/libodb-2.4.0
server/third_party/_sources/libodb-pgsql-2.4.0
```

Рабочие install-каталоги:

```text
server/third_party/libodb
server/third_party/libodb-pgsql
```

После сборки появляются библиотеки:

```text
server/third_party/libodb/lib/odb.lib
server/third_party/libodb-pgsql/lib/odb-pgsql.lib
```

На Unix-подобных системах имена будут другими:

```text
server/third_party/libodb/lib/libodb.a
server/third_party/libodb-pgsql/lib/libodb-pgsql.a
```

Именно поэтому в CMake не захардкожено расширение `.lib`. Используются переменные:

```cmake
CMAKE_STATIC_LIBRARY_PREFIX
CMAKE_STATIC_LIBRARY_SUFFIX
```

На Windows они дают имя вида `odb.lib`, а на Linux/macOS - `libodb.a`.

## Почему ODB собирается как C++14

Основной сервер собирается как C++20:

```cmake
set(CMAKE_CXX_STANDARD 20)
```

Но ODB 2.4.0 выпущен в 2015 году. В его исходниках встречаются конструкции старого C++:

```cpp
std::auto_ptr
throw (std::bad_alloc)
```

В C++17 и новее `std::auto_ptr` удален, а dynamic exception specifications запрещены. Поэтому при попытке собрать ODB как C++20 компилятор падает с ошибками.

Решение: сервер остается C++20, а локальная runtime-сборка ODB выполняется отдельным CMake-проектом со стандартом C++14:

```cmake
set(CMAKE_CXX_STANDARD 14)
```

Это нормальная практика: внешняя библиотека может быть собрана своим стандартом, а основной проект - своим. Важно, чтобы ABI и тип библиотек были совместимы с компилятором и линковщиком.

## Главный CMake-файл сервера

Файл:

```text
server/CMakeLists.txt
```

Ниже разбор основных команд.

```cmake
cmake_minimum_required(VERSION 3.25)
```

Указывает минимальную версию CMake. Это важно, потому что проект использует современные target-based команды и generator expressions. Если CMake старее 3.25, лучше сразу получить понятную ошибку.

```cmake
project(farm_association_server VERSION 0.1.0 LANGUAGES CXX)
```

Объявляет проект. Имя проекта - `farm_association_server`, версия - `0.1.0`, язык - C++.

```cmake
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
```

Эти строки задают стандарт C++20 для основного сервера.

`CMAKE_CXX_STANDARD_REQUIRED ON` означает: если компилятор не умеет C++20, CMake не должен молча переключаться на другой стандарт.

`CMAKE_CXX_EXTENSIONS OFF` означает: использовать стандартный режим C++20, а не расширения компилятора вроде GNU++20.

```cmake
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)
```

Просит CMake генерировать `compile_commands.json`. Этот файл полезен для clangd, IDE, статического анализа и отладки команд компиляции.

```cmake
option(FARM_SERVER_WITH_ODB "Build with ODB PostgreSQL support" ON)
```

Опция включает или отключает поддержку ODB. По умолчанию включена.

Если нужно временно собрать сервер без ODB:

```powershell
cmake -S server -B server\build -DFARM_SERVER_WITH_ODB=OFF
```

```cmake
option(FARM_SERVER_ODB_STATIC "Link ODB runtime as static libraries" ON)
```

Опция сообщает проекту, что ODB runtime подключается как статическая библиотека. При включении добавляются compile definitions:

```cmake
LIBODB_STATIC_LIB
LIBODB_PGSQL_STATIC_LIB
```

Они нужны заголовкам ODB, чтобы правильно обрабатывать экспорт/импорт символов.

```cmake
option(FARM_SERVER_BUILD_LOCAL_ODB_DEPS
    "Build local libodb/libodb-pgsql archives into server/third_party when they are missing" ON)
```

Это новая важная опция. Она включает автоматическую локальную сборку `libodb` и `libodb-pgsql` из исходников, которые лежат в `server/third_party/_sources`.

Если опция включена, первый `cmake --build` соберет ODB runtime один раз. Повторные сборки не будут делать это заново, потому что используется stamp-файл.

Если опция выключена, CMake ожидает, что готовые библиотеки уже лежат в `server/third_party/libodb/lib` и `server/third_party/libodb-pgsql/lib`.

```cmake
set(FARM_SERVER_DEPS_DIR
    "${CMAKE_CURRENT_SOURCE_DIR}/third_party"
    CACHE PATH "Directory with local project dependencies")
```

Задает путь к локальным зависимостям. По умолчанию это `server/third_party`.

`CACHE PATH` делает переменную настраиваемой из командной строки:

```powershell
cmake -S server -B server\build -DFARM_SERVER_DEPS_DIR=D:\some\other\deps
```

```cmake
list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/cmake")
include(FarmLocalDependencies)
```

Добавляет `server/cmake` в путь поиска CMake-модулей и подключает файл:

```text
server/cmake/FarmLocalDependencies.cmake
```

В этом файле лежат вспомогательные функции для поиска и сборки локальных зависимостей.

```cmake
farm_detect_platform(FARM_SERVER_PLATFORM)
message(STATUS "Farm server target platform: ${FARM_SERVER_PLATFORM}")
message(STATUS "Farm server local dependencies: ${FARM_SERVER_DEPS_DIR}")
```

Определяет платформу и печатает ее при конфигурации. Это помогает сразу увидеть, как CMake понял систему: `windows`, `linux` или `macos`.

```cmake
find_package(Threads REQUIRED)
```

Находит поддержку потоков. На Windows это может не добавлять отдельную библиотеку, на Linux обычно добавляет pthread. Использование `Threads::Threads` переносимее, чем вручную писать `pthread`.

```cmake
farm_add_boost_headers(farm_boost "${FARM_SERVER_DEPS_DIR}")
farm_add_nlohmann_json(farm_nlohmann_json "${FARM_SERVER_DEPS_DIR}")
```

Создает interface targets для Boost и nlohmann/json. Они не компилируют код, а только передают include paths и compile definitions основному target.

```cmake
add_executable(farm_association_server)
```

Создает исполняемый файл сервера.

```cmake
target_sources(farm_association_server
    PRIVATE
        src/main.cpp)
```

Добавляет исходный файл `src/main.cpp` в target. Используется target-based стиль, чтобы настройки были привязаны к конкретной цели.

```cmake
target_include_directories(farm_association_server
    PRIVATE
        "${CMAKE_CURRENT_SOURCE_DIR}/include")
```

Добавляет каталог `server/include` для собственных заголовков проекта.

`PRIVATE` означает, что include path нужен только самому серверу, а не тем, кто потенциально будет линковаться с ним.

```cmake
target_link_libraries(farm_association_server
    PRIVATE
        Threads::Threads
        farm_boost
        farm_nlohmann_json)
```

Подключает потоки, Boost и nlohmann/json к серверу.

```cmake
if(WIN32)
    target_compile_definitions(farm_association_server PRIVATE _WIN32_WINNT=0x0601)
    target_link_libraries(farm_association_server PRIVATE ws2_32 mswsock)
endif()
```

На Windows Boost.Asio/Beast используют WinSock API. Поэтому нужны системные библиотеки:

```text
ws2_32
mswsock
```

`_WIN32_WINNT=0x0601` задает минимальную версию Windows API. `0x0601` соответствует Windows 7. Это нужно, чтобы заголовки Windows открыли нужные объявления функций.

## Как CMake подключает ODB

Весь ODB-блок находится внутри:

```cmake
if(FARM_SERVER_WITH_ODB)
    ...
endif()
```

Если `FARM_SERVER_WITH_ODB=OFF`, этот блок полностью пропускается.

Если включена локальная сборка:

```cmake
if(FARM_SERVER_BUILD_LOCAL_ODB_DEPS)
    farm_add_odb_local_build(farm_odb_local_dependencies "${FARM_SERVER_DEPS_DIR}")
```

Вызывается функция, которая создает отдельный custom target для сборки `libodb` и `libodb-pgsql`.

После вызова функция возвращает пути через переменные:

```cmake
set(ODB_LIBRARY "${farm_odb_local_dependencies_ODB_LIBRARY}")
set(ODB_PGSQL_LIBRARY "${farm_odb_local_dependencies_ODB_PGSQL_LIBRARY}")
set(ODB_INCLUDE_DIR "${farm_odb_local_dependencies_ODB_INCLUDE_DIR}")
set(ODB_PGSQL_INCLUDE_DIR "${farm_odb_local_dependencies_ODB_PGSQL_INCLUDE_DIR}")
set(POSTGRESQL_INCLUDE_DIR "${farm_odb_local_dependencies_POSTGRESQL_INCLUDE_DIR}")
```

Если локальная сборка выключена, CMake ищет уже готовые библиотеки:

```cmake
farm_find_local_library(ODB_LIBRARY ...)
farm_find_local_library(ODB_PGSQL_LIBRARY ...)
```

PostgreSQL `libpq` ищется в обоих случаях:

```cmake
farm_find_local_library(POSTGRESQL_LIBRARY "${FARM_SERVER_DEPS_DIR}" "libpq"
    REQUIRED
    NAMES pq libpq pq.lib libpq.lib
    PATHS
        "${FARM_SERVER_DEPS_DIR}/postgresql/lib"
        "${FARM_SERVER_DEPS_DIR}/libpq/lib")
```

Здесь `NAMES` перечисляет возможные имена библиотеки. Это нужно из-за различий платформ и компиляторов.

Далее создаются imported targets:

```cmake
farm_add_imported_library(ODB::odb "${ODB_LIBRARY}" "${ODB_INCLUDE_DIR}")
farm_add_imported_library(ODB::pgsql "${ODB_PGSQL_LIBRARY}" "${ODB_PGSQL_INCLUDE_DIR}")
farm_add_imported_library(PostgreSQL::pq "${POSTGRESQL_LIBRARY}" "${POSTGRESQL_INCLUDE_DIR}")
```

Imported target - это CMake-цель, которая описывает уже существующую библиотеку. CMake сам ее не собирает, но знает, где лежит файл библиотеки и какие include paths нужны потребителю.

Если локальный target зависимостей создан, сервер явно зависит от него:

```cmake
if(TARGET farm_odb_local_dependencies)
    add_dependencies(farm_association_server farm_odb_local_dependencies)
endif()
```

Это гарантирует порядок сборки: сначала `libodb` и `libodb-pgsql`, потом сервер.

Затем добавляется compile definition:

```cmake
target_compile_definitions(farm_association_server PRIVATE FARM_SERVER_WITH_ODB=1)
```

Он позволяет C++-коду при необходимости проверять:

```cpp
#ifdef FARM_SERVER_WITH_ODB
```

После этого при статической линковке добавляются определения ODB:

```cmake
LIBODB_STATIC_LIB
LIBODB_PGSQL_STATIC_LIB
```

И наконец сервер линкуется с ODB и PostgreSQL:

```cmake
target_link_libraries(farm_association_server PRIVATE ODB::odb ODB::pgsql PostgreSQL::pq)
```

## Файл FarmLocalDependencies.cmake

Файл:

```text
server/cmake/FarmLocalDependencies.cmake
```

Он создан, чтобы вынести из основного `CMakeLists.txt` всю низкоуровневую работу с зависимостями.

```cmake
include_guard(GLOBAL)
```

Защищает файл от повторного подключения. Если CMake-модуль будет включен несколько раз, функции не будут переопределяться повторно.

```cmake
function(farm_detect_platform out_var)
```

Функция определяет платформу. На Windows возвращает `windows`, на macOS - `macos`, на Linux/Unix - `linux`.

Результат возвращается через:

```cmake
set(${out_var} "${platform}" PARENT_SCOPE)
```

`PARENT_SCOPE` нужен, потому что переменные внутри функции CMake имеют локальную область видимости. Без `PARENT_SCOPE` вызывающий код не увидел бы результат.

```cmake
function(farm_require_path path description)
```

Проверяет существование файла или каталога. Если пути нет, вызывает:

```cmake
message(FATAL_ERROR ...)
```

Это останавливает конфигурацию с понятным сообщением. Такой подход лучше, чем позволить сборке упасть позже с неочевидной ошибкой компилятора.

```cmake
function(farm_add_boost_headers target deps_dir)
```

Создает interface target для Boost:

```cmake
add_library(${target} INTERFACE)
```

`INTERFACE` означает, что библиотека сама не содержит исходников и не собирает артефакт. Она только передает свойства тем target, которые с ней линкуются.

```cmake
target_include_directories(${target} INTERFACE "${include_dir}")
```

Передает include path потребителям.

```cmake
target_compile_definitions(${target} INTERFACE ...)
```

Передает compile definitions потребителям.

```cmake
if(EXISTS "${deps_dir}/boost/lib")
    target_link_directories(${target} INTERFACE "${deps_dir}/boost/lib")
endif()
```

Если есть каталог с Boost-библиотеками, он добавляется в link search path. Сейчас сервер использует Boost в header-only режиме, но наличие `boost/lib` оставлено для дальнейшего развития.

```cmake
function(farm_add_nlohmann_json target deps_dir)
```

Аналогичная interface-функция для nlohmann/json.

```cmake
function(farm_find_local_program out_var deps_dir program_name)
```

Ищет локальную программу, например `odb.exe`. Она ищет в:

```text
server/third_party/odb/bin/windows
server/third_party/odb/bin
```

`NO_DEFAULT_PATH` запрещает CMake искать программу в системном PATH. Это важно: если на компьютере глобально установлен другой `odb`, проект не должен случайно взять его.

```cmake
function(farm_find_local_library out_var deps_dir package_name)
```

Ищет локальную библиотеку. Она добавляет к указанным путям варианты:

```text
<path>/<platform>
<path>/<CMAKE_SYSTEM_PROCESSOR>
<path>
```

Например для Windows и AMD64 поиск может идти по:

```text
server/third_party/libodb/lib/windows
server/third_party/libodb/lib/AMD64
server/third_party/libodb/lib
```

Это сделано для переносимости. Если позже понадобится хранить библиотеки по платформам, CMake уже умеет такие каталоги проверять.

```cmake
function(farm_add_imported_library target library_path include_dirs)
```

Создает imported target:

```cmake
add_library(${target} UNKNOWN IMPORTED)
```

`UNKNOWN` означает, что CMake не обязан заранее знать тип библиотеки. Это удобно, когда на разных платформах могут быть `.lib`, `.a`, `.so` или `.dylib`.

```cmake
set_target_properties(${target} PROPERTIES
    IMPORTED_LOCATION "${library_path}"
    INTERFACE_INCLUDE_DIRECTORIES "${include_dirs}")
```

`IMPORTED_LOCATION` указывает путь к файлу библиотеки.

`INTERFACE_INCLUDE_DIRECTORIES` говорит, какие include paths должен получить target, который будет линковаться с этой imported-библиотекой.

```cmake
function(farm_add_runtime_paths target)
```

Добавляет runtime search paths для Unix-подобных систем.

На macOS:

```cmake
INSTALL_RPATH "@loader_path;${paths}"
```

На Linux:

```cmake
INSTALL_RPATH "$ORIGIN;${paths}"
```

На Windows RPATH не используется, потому что DLL ищутся по другим правилам: рядом с `.exe`, в PATH и системных каталогах.

## Как работает одноразовая сборка ODB

Главная функция:

```cmake
farm_add_odb_local_build(farm_odb_local_dependencies "${FARM_SERVER_DEPS_DIR}")
```

Она находится в `FarmLocalDependencies.cmake`.

Сначала функция вычисляет пути:

```cmake
set(odb_source_dir "${deps_dir}/_sources/libodb-2.4.0")
set(odb_pgsql_source_dir "${deps_dir}/_sources/libodb-pgsql-2.4.0")
set(postgresql_dir "${deps_dir}/postgresql")
set(local_build_project "${CMAKE_CURRENT_SOURCE_DIR}/cmake/odb-local")
```

Затем проверяет, что исходники на месте:

```cmake
farm_require_path("${odb_source_dir}/odb/database.hxx" "libodb sources")
farm_require_path("${odb_pgsql_source_dir}/odb/pgsql/database.hxx" "libodb-pgsql sources")
farm_require_path("${postgresql_dir}/include/libpq-fe.h" "PostgreSQL libpq headers")
```

После этого создает install-каталоги:

```cmake
file(MAKE_DIRECTORY
    "${deps_dir}/libodb/include"
    "${deps_dir}/libodb/lib"
    "${deps_dir}/libodb-pgsql/include"
    "${deps_dir}/libodb-pgsql/lib")
```

Build-каталог зависит от платформы, компилятора и процессора:

```cmake
set(build_dir
    "${deps_dir}/_build/odb-local/${platform}-${CMAKE_CXX_COMPILER_ID}-${CMAKE_SYSTEM_PROCESSOR}")
```

Например на текущей Windows-сборке это:

```text
server/third_party/_build/odb-local/windows-Clang-AMD64
```

Это нужно, чтобы не смешивать результаты разных toolchain. Если собрать проект GCC и Clang в один и тот же каталог, объектные файлы и настройки могут конфликтовать.

Дальше задается stamp-файл:

```cmake
set(stamp_file "${build_dir}/farm-odb-local.stamp")
```

Stamp-файл - это маркер успешного завершения custom command. Пока он существует и новее зависимостей, Ninja считает цель собранной и не запускает команду заново.

Пути к ожидаемым библиотекам строятся переносимо:

```cmake
set(odb_library
    "${deps_dir}/libodb/lib/${CMAKE_STATIC_LIBRARY_PREFIX}odb${CMAKE_STATIC_LIBRARY_SUFFIX}")
set(odb_pgsql_library
    "${deps_dir}/libodb-pgsql/lib/${CMAKE_STATIC_LIBRARY_PREFIX}odb-pgsql${CMAKE_STATIC_LIBRARY_SUFFIX}")
```

На Windows это дает:

```text
odb.lib
odb-pgsql.lib
```

На Linux/macOS:

```text
libodb.a
libodb-pgsql.a
```

Команда конфигурации вложенного проекта собирается в список `configure_args`:

```cmake
set(configure_args
    -S "${local_build_project}"
    -B "${build_dir}"
    -G "${CMAKE_GENERATOR}"
    "-DTHIRD_PARTY_DIR=${deps_dir}"
    "-DCMAKE_CXX_STANDARD=14")
```

`-S` указывает исходный каталог CMake-проекта для ODB.

`-B` указывает build-каталог.

`-G` передает тот же генератор, что использует основной проект. Если основной проект собирается Ninja, ODB тоже собирается Ninja. Если Visual Studio - ODB тоже через Visual Studio.

`THIRD_PARTY_DIR` говорит вложенному проекту, где находится `server/third_party`.

`CMAKE_CXX_STANDARD=14` нужен, потому что ODB 2.4.0 не компилируется как C++20.

Если в основном проекте явно задан компилятор, он передается вложенному проекту:

```cmake
if(CMAKE_CXX_COMPILER)
    list(APPEND configure_args "-DCMAKE_CXX_COMPILER=${CMAKE_CXX_COMPILER}")
endif()
```

Если используется Visual Studio generator с платформой или toolset, они тоже передаются:

```cmake
if(CMAKE_GENERATOR_PLATFORM)
    list(APPEND configure_args -A "${CMAKE_GENERATOR_PLATFORM}")
endif()

if(CMAKE_GENERATOR_TOOLSET)
    list(APPEND configure_args -T "${CMAKE_GENERATOR_TOOLSET}")
endif()
```

Для single-config генераторов вроде Ninja передается build type:

```cmake
if(NOT CMAKE_CONFIGURATION_TYPES AND CMAKE_BUILD_TYPE)
    list(APPEND configure_args "-DCMAKE_BUILD_TYPE=${CMAKE_BUILD_TYPE}")
endif()
```

Для multi-config генераторов вроде Visual Studio build type передается не на конфигурации, а на сборке:

```cmake
set(build_args --build "${build_dir}")
if(CMAKE_CONFIGURATION_TYPES)
    list(APPEND build_args --config "$<CONFIG>")
endif()
```

`$<CONFIG>` - generator expression. Для Visual Studio он превратится в текущую конфигурацию: Debug, Release и так далее.

Ключевая часть:

```cmake
add_custom_command(
    OUTPUT
        "${stamp_file}"
    COMMAND "${CMAKE_COMMAND}" ${configure_args}
    COMMAND "${CMAKE_COMMAND}" ${build_args}
    COMMAND "${CMAKE_COMMAND}" -E touch "${stamp_file}"
    DEPENDS
        "${local_build_project}/CMakeLists.txt"
    BYPRODUCTS
        "${odb_library}"
        "${odb_pgsql_library}"
    COMMENT "Building local ODB runtime dependencies once"
    VERBATIM)
```

`OUTPUT "${stamp_file}"` говорит CMake/Ninja: результат этой команды - stamp-файл.

Первая `COMMAND` конфигурирует вложенный CMake-проект.

Вторая `COMMAND` собирает вложенный CMake-проект.

Третья `COMMAND` создает или обновляет stamp-файл.

`DEPENDS` указывает, что если `server/cmake/odb-local/CMakeLists.txt` изменится, custom command надо выполнить заново.

`BYPRODUCTS` перечисляет файлы, которые команда создает дополнительно: `odb.lib` и `odb-pgsql.lib`. Ninja важно знать о таких файлах, иначе он может не понимать, откуда они берутся.

`VERBATIM` просит CMake корректно экранировать аргументы команд. Это важно для путей с пробелами.

Дальше custom command превращается в target:

```cmake
add_custom_target(${target} DEPENDS "${stamp_file}")
```

И наружу возвращаются пути:

```cmake
set(${target}_ODB_LIBRARY "${odb_library}" PARENT_SCOPE)
set(${target}_ODB_PGSQL_LIBRARY "${odb_pgsql_library}" PARENT_SCOPE)
set(${target}_ODB_INCLUDE_DIR "${deps_dir}/libodb/include" PARENT_SCOPE)
set(${target}_ODB_PGSQL_INCLUDE_DIR "${deps_dir}/libodb-pgsql/include" PARENT_SCOPE)
set(${target}_POSTGRESQL_INCLUDE_DIR "${postgresql_dir}/include" PARENT_SCOPE)
```

## Вложенный CMake-проект odb-local

Файл:

```text
server/cmake/odb-local/CMakeLists.txt
```

Это отдельный маленький CMake-проект, задача которого - собрать только `libodb` и `libodb-pgsql`.

```cmake
cmake_minimum_required(VERSION 3.25)
project(odb_local_build LANGUAGES CXX)
```

Объявляет отдельный проект.

```cmake
set(CMAKE_CXX_STANDARD 14)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
```

Собирает ODB как C++14. Это принципиально из-за старого кода ODB 2.4.0.

```cmake
set(THIRD_PARTY_DIR
    "${CMAKE_CURRENT_LIST_DIR}/../../third_party"
    CACHE PATH "Farm server third_party directory")
```

Задает путь к `server/third_party`. Значение можно переопределить из основного CMake через `-DTHIRD_PARTY_DIR=...`.

```cmake
set(LIBODB_SOURCE_DIR "${THIRD_PARTY_DIR}/_sources/libodb-2.4.0")
set(LIBODB_PGSQL_SOURCE_DIR "${THIRD_PARTY_DIR}/_sources/libodb-pgsql-2.4.0")
set(POSTGRESQL_DIR "${THIRD_PARTY_DIR}/postgresql")
```

Задает входные каталоги исходников.

```cmake
set(LIBODB_INSTALL_DIR "${THIRD_PARTY_DIR}/libodb")
set(LIBODB_PGSQL_INSTALL_DIR "${THIRD_PARTY_DIR}/libodb-pgsql")
```

Задает выходные install-каталоги.

```cmake
file(MAKE_DIRECTORY ...)
```

Создает выходные `include` и `lib`, если их еще нет.

```cmake
add_custom_target(odb-local-headers
    COMMAND "${CMAKE_COMMAND}" -E copy_directory
        "${LIBODB_SOURCE_DIR}/odb"
        "${LIBODB_INSTALL_DIR}/include/odb"
    COMMAND "${CMAKE_COMMAND}" -E copy_directory
        "${LIBODB_PGSQL_SOURCE_DIR}/odb"
        "${LIBODB_PGSQL_INSTALL_DIR}/include/odb"
    COMMENT "Copying local ODB headers"
    VERBATIM)
```

Копирует заголовки ODB в рабочие install-каталоги.

Используется `cmake -E copy_directory`, потому что это переносимая команда CMake. Она работает на Windows, Linux и macOS одинаково.

Дальше вручную перечислены исходные файлы `libodb`:

```cmake
set(LIBODB_SOURCES
    ...
)
```

Они перечислены явно, а не через glob, чтобы сборка была предсказуемой. Если в исходниках появится лишний файл, он не подключится случайно.

Для Windows добавлены отдельные win32-файлы:

```cmake
if(WIN32)
    list(APPEND LIBODB_SOURCES
        "${LIBODB_SOURCE_DIR}/odb/details/win32/condition.cxx"
        ...
)
endif()
```

В ODB есть платформенно-зависимые реализации threading/condition/tls. На Windows нужны файлы из `odb/details/win32`.

```cmake
add_library(odb STATIC ${LIBODB_SOURCES})
```

Собирает статическую библиотеку `odb`.

```cmake
add_dependencies(odb odb-local-headers)
```

Гарантирует, что перед сборкой библиотеки заголовки будут скопированы в install-каталог.

```cmake
target_compile_definitions(odb PUBLIC LIBODB_STATIC_LIB)
```

Говорит заголовкам `libodb`, что библиотека собирается/используется статически.

```cmake
target_include_directories(odb PUBLIC "${LIBODB_SOURCE_DIR}")
```

Добавляет исходный include path для компиляции самой библиотеки.

```cmake
set_target_properties(odb PROPERTIES
    OUTPUT_NAME odb
    ARCHIVE_OUTPUT_DIRECTORY "${LIBODB_INSTALL_DIR}/lib")
```

Задает имя выходной библиотеки и каталог, куда положить архив.

Для multi-config генераторов дополнительно задан output directory для разных конфигураций:

```cmake
foreach(config DEBUG RELEASE RELWITHDEBINFO MINSIZEREL)
    set_target_properties(odb PROPERTIES
        ARCHIVE_OUTPUT_DIRECTORY_${config} "${LIBODB_INSTALL_DIR}/lib")
endforeach()
```

Без этого Visual Studio могла бы положить библиотеку в подкаталог `Debug` или `Release`. Проекту удобнее иметь стабильный путь:

```text
server/third_party/libodb/lib/odb.lib
```

Для `libodb-pgsql` логика такая же, но есть дополнительные include paths:

```cmake
target_include_directories(odb-pgsql
    PUBLIC
        "${LIBODB_SOURCE_DIR}"
        "${LIBODB_PGSQL_SOURCE_DIR}"
        "${POSTGRESQL_DIR}/include")
```

`libodb-pgsql` должен видеть:

1. Заголовки базового `libodb`.
2. Свои собственные заголовки.
3. Заголовки PostgreSQL `libpq`.

Также он линкуется с `odb`:

```cmake
target_link_libraries(odb-pgsql PUBLIC odb)
```

## Почему сборка проходит повторно без пересборки зависимостей

При первом запуске:

```powershell
cmake --build server\build
```

CMake/Ninja видит, что target `farm_odb_local_dependencies` зависит от stamp-файла:

```text
server/third_party/_build/odb-local/<platform>-<compiler>-<processor>/farm-odb-local.stamp
```

Если stamp-файла нет, выполняется вложенная сборка ODB:

```text
configure odb-local
build odb-local
touch farm-odb-local.stamp
```

После этого появляются:

```text
server/third_party/libodb/lib/odb.lib
server/third_party/libodb-pgsql/lib/odb-pgsql.lib
```

При повторном запуске Ninja видит, что stamp-файл уже есть, и пишет:

```text
ninja: no work to do.
```

Это значит, что внешние зависимости не пересобираются.

Если нужно принудительно пересобрать ODB:

```powershell
Remove-Item -Recurse -Force server\third_party\_build\odb-local
Remove-Item -Force server\third_party\libodb\lib\*
Remove-Item -Force server\third_party\libodb-pgsql\lib\*
cmake --build server\build
```

Перед удалением важно убедиться, что удаляются именно каталоги внутри проекта.

## Команды полной сборки проекта

Из корня проекта:

```powershell
cmake -S server -B server\build -G Ninja -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug
cmake --build server\build
ctest --test-dir server\build --output-on-failure
```

Запуск:

```powershell
.\server\build\farm_association_server.exe --version
.\server\build\farm_association_server.exe
```

На Linux/macOS команды почти такие же:

```bash
cmake -S server -B server/build -G Ninja -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug
cmake --build server/build
ctest --test-dir server/build --output-on-failure
./server/build/farm_association_server --version
./server/build/farm_association_server
```

## Что проверено

Проверена конфигурация отдельного build-каталога:

```powershell
cmake -S server -B server\build-deps-check -G Ninja -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug
```

Проверена сборка:

```powershell
cmake --build server\build-deps-check
```

При первом запуске были собраны `odb.lib` и `odb-pgsql.lib`.

Повторная сборка показала:

```text
ninja: no work to do.
```

Это подтверждает, что внешние зависимости не пересобираются каждый раз.

Проверены тесты:

```powershell
ctest --test-dir server\build-deps-check --output-on-failure
```

Результат:

```text
100% tests passed, 0 tests failed out of 1
```

## Краткий итог

В проекте сделана локальная, воспроизводимая схема зависимостей.

Boost и nlohmann/json подключаются как header-only/interface зависимости из `server/third_party`.

PostgreSQL используется как локальный client runtime через `libpq`.

ODB compiler лежит локально в `server/third_party/odb/bin`.

`libodb` и `libodb-pgsql` собираются автоматически один раз из исходников и затем переиспользуются.

Основной сервер остается C++20, а старый ODB 2.4.0 собирается отдельно как C++14.

CMake написан так, чтобы не зависеть от глобально установленных библиотек и учитывать различия Windows/Linux/macOS там, где это возможно.
