﻿# План кода: Boost.Beast server block + ODB

## Цепочка слоев

```text
Server block
  -> Handling
  -> HTTP Controller
  -> Application Controller
  -> Persistence objects
  -> Database layer
  -> ODB / PostgreSQL
```

`View` не является отдельным вызывающим слоем в цепочке. Это простая структура представления, которую создает HTTP controller после получения DTO от application controller.

Внутри `Server block`:

```text
Server
  -> Boost.Beast HTTP server
  -> RequestDispatcher
  -> AppRouter
  -> resource handlers
```

`Crow` не подключаем. Вместо него делаем свой `Server` с Crow-like API и отдельными handler-файлами по ресурсам.

`persistence` - только структуры с ODB pragmas. `database` - отдельный слой подключения к БД. `repository` не используем.

## Структура файлов

```text
server/
  include/
    controllers/
      app/
        Users.hpp
      dto/
        User.hpp
      http/
        Users.hpp
    database/
      database.hpp
    handling/
      Health.hpp
      Users.hpp
    marshalling/
      user.hpp
    persistence/
      user.hpp
    server/
      core/
        AppRouter.hpp
        HttpTypes.hpp
        RequestDispatcher.hpp
        server.hpp
    views/
      user.hpp
  src/
    controllers/
      app/
        Users.cpp
      http/
        Users.cpp
    database/
      database.cpp
    handling/
      Health.cpp
      Users.cpp
    server/
      core/
        AppRouter.cpp
        RequestDispatcher.cpp
        server.cpp
    main.cpp
```

## 1. Server HTTP-типы

`server/include/server/core/HttpTypes.hpp`

```cpp
#pragma once

#include <string>
#include <unordered_map>

struct HttpRequest {
  std::string method;
  std::string target;
  std::string body;
  std::unordered_map<std::string, std::string> headers;
};

struct HttpResponse {
  unsigned status{200};
  std::string content_type{"application/json"};
  std::string body;
};
```

## 2. Controller DTO

`server/include/controllers/dto/User.hpp`

```cpp
#pragma once

#include <string>

struct CreateUserCommand {
  std::string name;
};

struct UserDto {
  unsigned long id{};
  std::string name;
};
```

## 3. Persistence object

`server/include/persistence/User.hpp`

```cpp
#pragma once

#include <odb/core.hxx>

#include <string>

#pragma db object
class User {
public:
  User() = default;
  explicit User(std::string name) : name_(std::move(name)) {}

  unsigned long id() const { return id_; }
  const std::string& name() const { return name_; }

private:
  friend class odb::access;

  #pragma db id auto
  unsigned long id_{};

  std::string name_;
};
```

ODB-код генерируется при сборке через CMake.

Сгенерированные файлы должны попадать в:

```text
server/build/generated/persistence/
  user-odb.cxx
  user-odb.hxx
  user-odb.ixx
  user.sql
```

## 4. Database layer

`server/include/database/database.hpp`

```cpp
#pragma once

#include <functional>
#include <memory>
#include <odb/database.hxx>
#include <odb/exceptions.hxx>
#include <odb/transaction.hxx>
#include <type_traits>
#include <utility>

namespace fasc::server::database {
class Transaction {
public:
  explicit Transaction(odb::database& database);

  ~Transaction() noexcept;

  void commit();
  void rollback();
};

class Database {
public:
  explicit Database(std::unique_ptr<odb::database> database);

  static Database createFromEnv();

  Transaction makeTransaction();
  bool hasActiveTransaction() const;

  template <typename Work>
  decltype(auto) invokeTransactionally(Work&& work);

  template <typename Entity>
  auto persist(Entity& entity);

  template <typename Entity>
  void update(Entity& entity);

  template <typename Entity>
  void erase(Entity& entity);

  template <typename Entity, typename Id>
  bool eraseById(const Id& id);
};

} // namespace fasc::server::database
```

`server/src/database/database.cpp`

```cpp
#include <database/database.hpp>

#include <odb/pgsql/database.hxx>

Database Database::createFromEnv() {
  return Database{std::make_unique<odb::pgsql::database>(
      env_or("FARM_DB_USER", "postgres"),
      env_or("FARM_DB_PASSWORD", "password"),
      env_or("FARM_DB_NAME", "farm_association"),
      env_or("FARM_DB_HOST", "localhost"),
      env_port_or("FARM_DB_PORT", 5432))};
}
```

`Database` владеет реальным `odb::database`, создает подключение из переменных окружения и дает обертки `persist`, `update`, `erase`, `eraseById`, `makeTransaction` и `invokeTransactionally`.

## 5. Application controller

`server/include/controllers/app/Users.hpp`

```cpp
#pragma once

#include <controllers/dto/User.hpp>
#include <database/database.hpp>

class UserController {
public:
  explicit UserController(fasc::server::database::Database& db);

  UserDto create_user(CreateUserCommand command);

private:
  fasc::server::database::Database& db_;
};
```

`server/src/controllers/app/Users.cpp`

```cpp
#include <controllers/app/Users.hpp>

#include <persistence/User.hpp>
#include <persistence/user-odb.hxx>

#include <stdexcept>

UserController::UserController(fasc::server::database::Database& db) : db_(db) {}

UserDto UserController::create_user(CreateUserCommand command) {
  if (command.name.empty()) {
    throw std::invalid_argument("User name is required");
  }

  return db_.invokeTransactionally([&] {
    User user{std::move(command.name)};
    db_.persist(user);

    return UserDto{user.id(), user.name()};
  });
}
```

## 6. View layer

`server/include/views/User.hpp`

```cpp
#pragma once

#include <string>

struct UserView {
  unsigned long id{};
  std::string name;
};
```

View - это простая структура наружного представления ресурса. Для persistence object это публичная форма объекта, например `UserView` может быть похож на `persistence::User`, но без пароля, внутренних флагов и других полей, которые нельзя отдавать наружу.

View не хранит HTTP status, content type и другие свойства ответа. Эти данные принадлежат `HttpResponse` и выставляются HTTP controller-ом.

Handler не должен собирать JSON из view. Handler только передает `HttpRequest` в HTTP controller и возвращает готовый `HttpResponse`.

JSON-преобразования лежат в отдельном слое `marshalling`: `to_json` используется для view, а `from_json` - для входящих DTO/command. Persistence objects не парсятся напрямую из внешнего JSON.

## 7. HTTP controller

`server/include/controllers/http/Users.hpp`

```cpp
#pragma once

#include <server/core/HttpTypes.hpp>
#include <controllers/app/Users.hpp>
#include <views/User.hpp>

class UserHttpController {
public:
  explicit UserHttpController(UserController& users);

  HttpResponse create_user(const HttpRequest& request);

private:
  UserController& users_;
};
```

`server/src/controllers/http/Users.cpp`

```cpp
#include <controllers/http/Users.hpp>

#include <marshalling/User.hpp>

#include <nlohmann/json.hpp>

UserHttpController::UserHttpController(UserController& users) : users_(users) {}

HttpResponse UserHttpController::create_user(const HttpRequest& request) {
  auto command = nlohmann::json::parse(request.body).get<CreateUserCommand>();

  const UserDto user = users_.create_user(std::move(command));
  const UserView view{user.id, user.name};
  const nlohmann::json body = view;

  return HttpResponse{201, "application/json", body.dump()};
}
```

## 8. AppRouter внутри server/core

`server/include/server/core/AppRouter.hpp`

```cpp
#pragma once

#include <server/core/HttpTypes.hpp>

#include <functional>
#include <string>
#include <unordered_map>

class AppRouter {
public:
  using RouteHandler = std::function<HttpResponse(const HttpRequest&)>;

  void get(std::string path, RouteHandler handler);
  void post(std::string path, RouteHandler handler);

  HttpResponse route(const HttpRequest& request) const;

private:
  std::unordered_map<std::string, RouteHandler> routes_;

  static std::string key(std::string method, std::string path);
};
```

`server/src/server/core/AppRouter.cpp`

```cpp
#include <server/core/AppRouter.hpp>

#include <utility>

void AppRouter::get(std::string path, RouteHandler handler) {
  routes_.emplace(key("GET", std::move(path)), std::move(handler));
}

void AppRouter::post(std::string path, RouteHandler handler) {
  routes_.emplace(key("POST", std::move(path)), std::move(handler));
}

HttpResponse AppRouter::route(const HttpRequest& request) const {
  const auto it = routes_.find(key(request.method, request.target));
  if (it == routes_.end()) {
    return HttpResponse{404, "application/json", R"({"error":"not found"})"};
  }

  return it->second(request);
}

std::string AppRouter::key(std::string method, std::string path) {
  return std::move(method) + " " + std::move(path);
}
```

## 9. Handling layer

### Health handler

`server/include/handling/Health.hpp`

```cpp
#pragma once

#include <server/core/HttpTypes.hpp>

class HealthHandler {
public:
  HttpResponse health(const HttpRequest& request);
};
```

`server/src/handling/Health.cpp`

```cpp
#include <handling/Health.hpp>

HttpResponse HealthHandler::health(const HttpRequest&) {
  return HttpResponse{200, "application/json", R"({"status":"ok"})"};
}
```

### User handler

`server/include/handling/Users.hpp`

```cpp
#pragma once

#include <controllers/http/Users.hpp>
#include <server/core/HttpTypes.hpp>

class UserHandler {
public:
  explicit UserHandler(UserHttpController& users);

  HttpResponse create_user(const HttpRequest& request);

private:
  UserHttpController& users_;
};
```

`server/src/handling/Users.cpp`

```cpp
#include <handling/Users.hpp>

UserHandler::UserHandler(UserHttpController& users) : users_(users) {}

HttpResponse UserHandler::create_user(const HttpRequest& request) {
  return users_.create_user(request);
}
```

Handler-файлы в `handling` связывают server routes с HTTP controllers. Это отдельный слой выше `server/core`, потому что он уже знает про конкретные ресурсы приложения. В нем не должно быть бизнес-логики, ODB, PostgreSQL и сборки представления. Его задача - вызвать нужный метод HTTP controller.

## 10. RequestDispatcher внутри server/core

`server/include/server/core/RequestDispatcher.hpp`

```cpp
#pragma once

#include <server/core/AppRouter.hpp>

#include <boost/beast/http.hpp>

namespace http = boost::beast::http;

using BeastRequest = http::request<http::string_body>;
using BeastResponse = http::response<http::string_body>;

class RequestDispatcher {
public:
  explicit RequestDispatcher(AppRouter& router);

  BeastResponse dispatch(const BeastRequest& request);

private:
  AppRouter& router_;
};
```

`server/src/server/core/RequestDispatcher.cpp`

```cpp
#include <server/core/RequestDispatcher.hpp>

#include <string>

RequestDispatcher::RequestDispatcher(AppRouter& router) : router_(router) {}

BeastResponse RequestDispatcher::dispatch(const BeastRequest& request) {
  HttpRequest app_request;
  app_request.method = std::string(request.method_string());
  app_request.target = std::string(request.target());
  app_request.body = request.body();

  for (const auto& field : request) {
    app_request.headers.emplace(
        std::string(field.name_string()),
        std::string(field.value()));
  }

  const HttpResponse app_response = router_.route(app_request);

  BeastResponse response{
      static_cast<http::status>(app_response.status),
      request.version()};

  response.set(http::field::server, "farm-association-server");
  response.set(http::field::content_type, app_response.content_type);
  response.keep_alive(request.keep_alive());
  response.body() = app_response.body;
  response.prepare_payload();

  return response;
}
```

## 11. Server block

`server/include/server/core/Server.hpp`

```cpp
#pragma once

#include <server/core/AppRouter.hpp>

class Server {
public:
  void get(std::string path, AppRouter::RouteHandler handler);
  void post(std::string path, AppRouter::RouteHandler handler);

  int run(unsigned short port);

private:
  AppRouter router_;
};
```

`server/src/server/core/Server.cpp`

```cpp
#include <server/core/Server.hpp>

#include <server/core/RequestDispatcher.hpp>

#include <boost/asio/ip/tcp.hpp>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>

#include <utility>

void Server::get(std::string path, AppRouter::RouteHandler handler) {
  router_.get(std::move(path), std::move(handler));
}

void Server::post(std::string path, AppRouter::RouteHandler handler) {
  router_.post(std::move(path), std::move(handler));
}

int Server::run(unsigned short port) {
  namespace asio = boost::asio;
  namespace http = boost::beast::http;
  using tcp = asio::ip::tcp;

  asio::io_context io;
  tcp::acceptor acceptor{io, {tcp::v4(), port}};
  RequestDispatcher dispatcher{router_};

  for (;;) {
    tcp::socket socket{io};
    acceptor.accept(socket);

    boost::beast::flat_buffer buffer;
    BeastRequest request;
    http::read(socket, buffer, request);

    BeastResponse response = dispatcher.dispatch(request);
    http::write(socket, response);
  }
}
```

## 12. main.cpp

```cpp
#include <controllers/app/Users.hpp>
#include <controllers/http/Users.hpp>
#include <database/database.hpp>
#include <server/core/Server.hpp>
#include <handling/Health.hpp>
#include <handling/Users.hpp>

#include <iostream>

int main() {
  auto database = fasc::server::database::Database::createFromEnv();

  UserController user_controller{database};
  UserHttpController user_http_controller{user_controller};

  HealthHandler health_handler;
  UserHandler user_handler{user_http_controller};

  Server server;
  server.get("/health", [&](const HttpRequest& request) {
    return health_handler.health(request);
  });
  server.post("/users", [&](const HttpRequest& request) {
    return user_handler.create_user(request);
  });

  std::cout << "Server started on port 8080\n";
  return server.run(8080);
}
```

## 13. CMake

Добавить правило генерации ODB:

```cmake
set(FARM_SERVER_ODB_COMPILER "${FARM_SERVER_DEPS_DIR}/odb/bin/odb.exe")
set(FARM_SERVER_USER_MODEL "${CMAKE_CURRENT_SOURCE_DIR}/include/persistence/User.hpp")
set(FARM_SERVER_GENERATED_DIR "${CMAKE_CURRENT_BINARY_DIR}/generated")
set(FARM_SERVER_GENERATED_PERSISTENCE_DIR "${FARM_SERVER_GENERATED_DIR}/persistence")
set(FARM_SERVER_USER_ODB_CXX "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user-odb.cxx")
set(FARM_SERVER_USER_ODB_HXX "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user-odb.hxx")
set(FARM_SERVER_USER_ODB_IXX "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user-odb.ixx")
set(FARM_SERVER_USER_SQL "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user.sql")

add_custom_command(
    OUTPUT
        "${FARM_SERVER_USER_ODB_CXX}"
        "${FARM_SERVER_USER_ODB_HXX}"
        "${FARM_SERVER_USER_ODB_IXX}"
        "${FARM_SERVER_USER_SQL}"
    COMMAND "${CMAKE_COMMAND}" -E make_directory "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}"
    COMMAND "${FARM_SERVER_ODB_COMPILER}"
        --std c++14
        --database pgsql
        --generate-query
        --generate-schema
        --output-dir "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}"
        "${FARM_SERVER_USER_MODEL}"
    DEPENDS
        "${FARM_SERVER_USER_MODEL}"
        "${FARM_SERVER_ODB_COMPILER}"
    COMMENT "Generating ODB mapping for persistence/User.hpp"
    VERBATIM)
```

Добавить файлы в target:

```cmake
target_sources(farm_association_server
    PRIVATE
        src/main.cpp
        src/controllers/app/Users.cpp
        src/controllers/http/Users.cpp
        src/database/database.cpp
        src/server/core/AppRouter.cpp
        src/server/core/RequestDispatcher.cpp
        src/server/core/Server.cpp
        src/handling/Health.cpp
        src/handling/Users.cpp
        "${FARM_SERVER_USER_ODB_CXX}")
```

Добавить generated include path:

```cmake
target_include_directories(farm_association_server
    PRIVATE
        "${FARM_SERVER_GENERATED_DIR}"
        "${CMAKE_CURRENT_SOURCE_DIR}/include/persistence"
        "${CMAKE_CURRENT_SOURCE_DIR}/include")
```

## 14. Проверка

```powershell
cmake -S server -B server\build -G Ninja -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug
cmake --build server\build
server\build\farm_association_server.exe
curl http://localhost:8080/health
curl -X POST http://localhost:8080/users -H "Content-Type: application/json" -d "{\"name\":\"Alice\"}"
```
