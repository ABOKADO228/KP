﻿# Методичка по устройству сервера Boost.Beast + ODB

Документ описывает текущую учебную архитектуру сервера в этом проекте: что где лежит, зачем нужен каждый слой, как добавить новые сущности и как собрать такой же сервер.

## 1. Общая идея

Сервер состоит из нескольких слоев:

```text
Server block
  -> Handling
  -> HTTP Controller
  -> Application Controller
  -> Persistence objects
  -> Database layer
  -> ODB / PostgreSQL
```

`View` здесь не отдельный вызывающий слой между controller-ами. View - это простая структура представления, которую HTTP controller создает из DTO, полученного от application controller.

Внутри `Server block` спрятаны детали HTTP-сервера:

```text
Server
  -> Boost.Beast HTTP server
  -> RequestDispatcher
  -> AppRouter
  -> route callbacks into handling layer
```

Главное правило: внешний HTTP-транспорт не должен расползаться по всему приложению.

`Boost.Beast` живет внутри server block.  
`HttpRequest` и `HttpResponse` живут внутри server block.  
`Handling` связывает маршруты server block с HTTP controller-ами.  
`HTTP Controller` работает с HTTP-смыслом запроса.  
`View` описывает публичное представление ресурса, которое HTTP controller превратит в body HTTP response.  
`Application Controller` содержит бизнес-логику.  
`Persistence objects` - это ODB-классы с pragmas.  
`Database layer` создает подключение к PostgreSQL.

## 2. Текущая структура проекта

```text
server/
  CMakeLists.txt
  include/
    controllers/
      app/
        Users.hpp
      dto/
        User.hpp
      http/
        Users.hpp
    database/
      database.hpp
    handling/
      Health.hpp
      Users.hpp
    marshalling/
      user.hpp
    persistence/
      user.hpp
    server/
      core/
        AppRouter.hpp
        HttpTypes.hpp
        RequestDispatcher.hpp
        server.hpp
    views/
      user.hpp
  src/
    controllers/
      app/
        Users.cpp
      http/
        Users.cpp
    database/
      database.cpp
    handling/
      Health.cpp
      Users.cpp
    main.cpp
    server/
      core/
        AppRouter.cpp
        RequestDispatcher.cpp
        server.cpp
```

Сгенерированный ODB-код не хранится в `include/`. Он создается при сборке:

```text
server/build/generated/persistence/
  user-odb.cxx
  user-odb.hxx
  user-odb.ixx
  user.sql
```

## 3. Server block

Server block - это вся инфраструктура HTTP-сервера.

Он дает наружу простой API:

```cpp
Server server;

server.get("/health", handler);
server.post("/users", handler);

return server.run(8080);
```

Это похоже на Crow по удобству, но внутри используется Boost.Beast.

### `Server`

Файлы:

```text
server/include/server/core/Server.hpp
server/src/server/core/Server.cpp
```

`Server` хранит `AppRouter`, принимает маршруты через `get()` и `post()`, запускает TCP acceptor и читает HTTP-запросы через Boost.Beast.

Упрощенная логика:

```cpp
tcp::acceptor acceptor{io, {tcp::v4(), port}};
RequestDispatcher dispatcher{router_};

for (;;) {
  tcp::socket socket{io};
  acceptor.accept(socket);

  boost::beast::flat_buffer buffer;
  BeastRequest request;
  http::read(socket, buffer, request);

  BeastResponse response = dispatcher.dispatch(request);
  http::write(socket, response);
}
```

### `RequestDispatcher`

Файлы:

```text
server/include/server/core/RequestDispatcher.hpp
server/src/server/core/RequestDispatcher.cpp
```

`RequestDispatcher` переводит типы Boost.Beast в наши внутренние типы:

```text
boost::beast::http::request
  -> HttpRequest
```

И обратно:

```text
HttpResponse
  -> boost::beast::http::response
```

Он не знает про `UserController`, ODB или бизнес-логику.

### `HttpRequest` и `HttpResponse`

Файл:

```text
server/include/server/core/HttpTypes.hpp
```

Это простые внутренние HTTP-обертки:

```cpp
struct HttpRequest {
  std::string method;
  std::string target;
  std::string body;
  std::unordered_map<std::string, std::string> headers;
};

struct HttpResponse {
  unsigned status{200};
  std::string content_type{"application/json"};
  std::string body;
};
```

Они нужны, чтобы HTTP controllers не зависели от Boost.Beast.

### `AppRouter`

Файлы:

```text
server/include/server/core/AppRouter.hpp
server/src/server/core/AppRouter.cpp
```

`AppRouter` хранит таблицу маршрутов:

```cpp
std::unordered_map<std::string, RouteHandler> routes_;
```

Ключ строится из метода и пути:

```text
GET /health
POST /users
```

Регистрация маршрутов:

```cpp
server.get("/health", ...);
server.post("/users", ...);
```

## 4. Handling layer

Handlers лежат здесь:

```text
server/include/handling/
server/src/handling/
```

Handlers связывают маршруты server block с HTTP controllers.

Это отдельный слой выше `server/core`. `server/core` знает только про HTTP-инфраструктуру, маршрутизацию и `HttpRequest`/`HttpResponse`. `handling` уже знает про конкретные ресурсы приложения: user, farm, product и так далее.

Пример:

```text
UserHandler
  -> UserHttpController
```

`UserHandler` получает `HttpRequest`, вызывает HTTP controller и возвращает готовый `HttpResponse`.

Handler не должен знать, как именно DTO превращается в view и JSON. Это работа HTTP controller. Поэтому handler остается тонкой прослойкой между роутером и HTTP controller.

```cpp
HttpResponse UserHandler::create_user(const HttpRequest& request) {
  return users_.create_user(request);
}
```

Для каждой новой группы endpoint-ов можно делать отдельный handler:

```text
handling/Users.hpp
handling/farm_handler.hpp
handling/product_handler.hpp
```

## 5. HTTP Controller

Файлы:

```text
server/include/controllers/http/Users.hpp
server/src/controllers/http/Users.cpp
```

HTTP controller знает про:

```text
HttpRequest
JSON body
DTO
Application Controller
View
marshalling functions
```

HTTP controller не знает про:

```text
Boost.Beast
TCP sockets
PostgreSQL connection details
```

Пример:

```cpp
HttpResponse UserHttpController::create_user(const HttpRequest& request) {
  auto command = nlohmann::json::parse(request.body).get<CreateUserCommand>();

  const UserDto user = users_.create_user(std::move(command));
  const UserView view{user.id, user.name};
  const nlohmann::json body = view;

  return HttpResponse{201, "application/json", body.dump()};
}
```

Задачи HTTP controller:

1. Разобрать HTTP request body.
2. Создать DTO-команду.
3. Вызвать application controller.
4. Получить DTO результата от application controller.
5. Создать view.
6. Превратить view в JSON через `to_json`.
7. Вернуть `HttpResponse`.

Именно здесь находится граница между бизнес-логикой и представлением:

```text
business result DTO
  -> view struct
  -> marshalling/to_json
  -> JSON body
  -> HttpResponse
```

Application controller не знает про JSON и HTTP status. Handler не знает про DTO и view. HTTP controller соединяет эти две стороны.

JSON-преобразования вынесены в `server/include/marshalling/User.hpp`. `from_json` используется для входящих command/DTO, а `to_json` - для view. Persistence object не должен быть внешним JSON-контрактом, потому что это внутренняя ODB-модель хранения.

## 6. View layer

Views лежат здесь:

```text
server/include/views/
```

View - это простая структура публичного представления ресурса. HTTP controller создает ее из DTO и на ее основе собирает body ответа.

View не хранит HTTP status, content type, headers и другие свойства HTTP-ответа. Это ответственность HTTP controller и `HttpResponse`. View отвечает только за то, какие поля ресурса видны наружу. Например, view для persistence user может быть похож на `persistence::User`, но без password/hash, служебных флагов и внутренних полей.

Пример:

```cpp
struct UserView {
  unsigned long id{};
  std::string name;
};
```

Почему view не возвращает сразу JSON:

1. View должен быть обычной структурой данных.
2. JSON - это уже формат транспорта.
3. HTTP controller решает, какой HTTP status и headers будут у ответа.
4. Так бизнес-логика не смешивается с представлением, а view не превращается в инфраструктурный класс.

Для новых сущностей можно добавлять:

```text
views/User.hpp
views/farm.hpp
views/product.hpp
```

## 7. DTO

DTO лежат здесь:

```text
server/include/controllers/dto/
```

DTO - это структуры для передачи данных между HTTP controller и application controller.

Пример:

```cpp
struct CreateUserCommand {
  std::string name;
};

struct UserDto {
  unsigned long id{};
  std::string name;
};
```

DTO не должны зависеть от Boost.Beast, PostgreSQL или ODB.

## 8. Application Controller

Файлы:

```text
server/include/controllers/app/Users.hpp
server/src/controllers/app/Users.cpp
```

Application controller содержит бизнес-логику и работает с persistence objects.

Сейчас `UserController` получает ссылку на проектную обертку `fasc::server::database::Database`:

```cpp
class UserController {
public:
  explicit UserController(fasc::server::database::Database& db);

  UserDto create_user(CreateUserCommand command);

private:
  fasc::server::database::Database& db_;
};
```

Создание пользователя:

```cpp
UserDto UserController::create_user(CreateUserCommand command) {
  if (command.name.empty()) {
    throw std::invalid_argument("User name is required");
  }

  return db_.invokeTransactionally([&] {
    User user{std::move(command.name)};
    db_.persist(user);

    return UserDto{user.id(), user.name()};
  });
}
```

Здесь находятся:

```text
валидация
бизнес-правила
работа с persistence object
граница транзакции через Database::invokeTransactionally
```

## 9. Persistence objects

Persistence objects лежат здесь:

```text
server/include/persistence/
```

Это классы с ODB pragmas.

Пример:

```cpp
#pragma db object
class User {
public:
  User() = default;
  explicit User(std::string name) : name_(std::move(name)) {}

  unsigned long id() const { return id_; }
  const std::string& name() const { return name_; }

private:
  friend class odb::access;

#pragma db id auto
  unsigned long id_{};

  std::string name_;
};
```

Важное правило проекта: generated ODB-файлы не лежат рядом с исходным `user.hpp`. Они создаются в `build/generated`.

## 10. Database layer

Файлы:

```text
server/include/database/database.hpp
server/src/database/database.cpp
```

Database layer создает подключение к PostgreSQL и дает удобные обертки над ODB-операциями:

```cpp
Database Database::createFromEnv() {
  return Database{std::make_unique<odb::pgsql::database>(
      env_or("FARM_DB_USER", "postgres"),
      env_or("FARM_DB_PASSWORD", "password"),
      env_or("FARM_DB_NAME", "farm_association"),
      env_or("FARM_DB_HOST", "localhost"),
      env_port_or("FARM_DB_PORT", 5432))};
}
```

Основные методы:

```text
createFromEnv()
  создает Database из переменных окружения

makeTransaction()
  вручную открывает Transaction или присоединяется к активной транзакции на той же базе

invokeTransactionally()
  выполняет callback внутри транзакции

persist/update/erase/eraseById()
  короткие обертки над ODB
```

Можно настроить подключение через переменные окружения:

```powershell
$env:FARM_DB_USER = "postgres"
$env:FARM_DB_PASSWORD = "password"
$env:FARM_DB_NAME = "farm_association"
$env:FARM_DB_HOST = "localhost"
$env:FARM_DB_PORT = "5432"
```

## 11. ODB generation при сборке

ODB compiler:

```text
server/third_party/odb/bin/odb.exe
```

CMake генерирует ODB-файлы автоматически:

```text
server/build/generated/persistence/
  user-odb.cxx
  user-odb.hxx
  user-odb.ixx
  user.sql
```

Ключевой фрагмент CMake:

```cmake
set(FARM_SERVER_ODB_COMPILER "${FARM_SERVER_DEPS_DIR}/odb/bin/odb.exe")
set(FARM_SERVER_USER_MODEL "${CMAKE_CURRENT_SOURCE_DIR}/include/persistence/User.hpp")
set(FARM_SERVER_GENERATED_DIR "${CMAKE_CURRENT_BINARY_DIR}/generated")
set(FARM_SERVER_GENERATED_PERSISTENCE_DIR "${FARM_SERVER_GENERATED_DIR}/persistence")
set(FARM_SERVER_USER_ODB_CXX "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user-odb.cxx")
set(FARM_SERVER_USER_ODB_HXX "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user-odb.hxx")
set(FARM_SERVER_USER_ODB_IXX "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user-odb.ixx")
set(FARM_SERVER_USER_SQL "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}/user.sql")

add_custom_command(
    OUTPUT
        "${FARM_SERVER_USER_ODB_CXX}"
        "${FARM_SERVER_USER_ODB_HXX}"
        "${FARM_SERVER_USER_ODB_IXX}"
        "${FARM_SERVER_USER_SQL}"
    COMMAND "${CMAKE_COMMAND}" -E make_directory "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}"
    COMMAND "${FARM_SERVER_ODB_COMPILER}"
        --std c++14
        --database pgsql
        --generate-query
        --generate-schema
        --output-dir "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}"
        "${FARM_SERVER_USER_MODEL}"
    DEPENDS
        "${FARM_SERVER_USER_MODEL}"
        "${FARM_SERVER_ODB_COMPILER}"
    COMMENT "Generating ODB mapping for persistence/User.hpp"
    VERBATIM)
```

Почему `--std c++14`, хотя проект собирается как C++20:

```text
ODB 2.4.0 старый и лучше генерирует код в режиме C++14.
Скомпилированный проект все равно собирается с C++20.
```

Для MSVC STL также добавлено:

```cmake
_HAS_AUTO_PTR_ETC=1
```

Это нужно, потому что ODB 2.4.0 использует старый `std::auto_ptr`.

## 12. Как добавить новую сущность

Предположим, нужна сущность `Farm`.

### 12.1. Persistence object

Создать:

```text
server/include/persistence/farm.hpp
```

Пример:

```cpp
#pragma once

#include <odb/core.hxx>

#include <string>

#pragma db object
class Farm {
public:
  Farm() = default;
  explicit Farm(std::string name) : name_(std::move(name)) {}

  unsigned long id() const { return id_; }
  const std::string& name() const { return name_; }

private:
  friend class odb::access;

#pragma db id auto
  unsigned long id_{};

  std::string name_;
};
```

### 12.2. DTO

Создать:

```text
server/include/controllers/dto/farm_dto.hpp
```

```cpp
struct CreateFarmCommand {
  std::string name;
};

struct FarmDto {
  unsigned long id{};
  std::string name;
};
```

### 12.3. View

Создать:

```text
server/include/views/farm.hpp
```

```cpp
struct FarmView {
  unsigned long id{};
  std::string name;
};
```

### 12.4. Application controller

Создать:

```text
server/include/controllers/app/farm_controller.hpp
server/src/controllers/app/farm_controller.cpp
```

Здесь будет бизнес-логика и `db_.persist(farm)`.

### 12.5. HTTP controller

Создать:

```text
server/include/controllers/http/farm_http_controller.hpp
server/src/controllers/http/farm_http_controller.cpp
```

Здесь будет парсинг `HttpRequest.body`, вызов `FarmController`, создание `FarmView` и возврат `HttpResponse`.

### 12.6. Server handler

Создать:

```text
server/include/handling/farm_handler.hpp
server/src/handling/farm_handler.cpp
```

Handler вызывает `FarmHttpController` и возвращает готовый `HttpResponse`.

### 12.7. CMake

Добавить генерацию ODB для `farm.hpp` по аналогии с `user.hpp`.

Добавить `.cpp` файлы в `target_sources`.

### 12.8. main.cpp

Зарегистрировать route:

```cpp
FarmController farm_controller{database};
FarmHttpController farm_http_controller{farm_controller};
FarmHandler farm_handler{farm_http_controller};

server.post("/farms", [&](const HttpRequest& request) {
  return farm_handler.create_farm(request);
});
```

## 13. Сборка

Из корня проекта:

```powershell
cmake -S server -B server\build -G Ninja -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug
cmake --build server\build
```

Что должно произойти:

```text
1. CMake конфигурирует проект.
2. Ninja запускает ODB compiler для persistence/User.hpp.
3. ODB-файлы появляются в server/build/generated/persistence.
4. Компилируется сервер.
5. Линкуется farm_association_server.exe.
6. PostgreSQL runtime DLLs копируются рядом с exe.
```

## 14. Проверка

Проверить версию:

```powershell
server\build\farm_association_server.exe --version
```

Запустить сервер:

```powershell
server\build\farm_association_server.exe
```

Проверить health:

```powershell
curl http://localhost:8080/health
```

Ожидаемый ответ:

```json
{"status":"ok"}
```

Проверить создание пользователя:

```powershell
curl -X POST http://localhost:8080/users -H "Content-Type: application/json" -d "{\"name\":\"Alice\"}"
```

Для успешного ответа должна быть поднята PostgreSQL БД `farm_association`, и в ней должна быть применена схема из:

```text
server/build/generated/persistence/user.sql
```

Пример применения схемы:

```powershell
server\third_party\postgresql\bin\createdb.exe -U postgres farm_association
server\third_party\postgresql\bin\psql.exe -U postgres -d farm_association -f server\build\generated\persistence\user.sql
```

Если PostgreSQL не запущен или база не создана, `/users` вернет ошибку сервера, потому что endpoint реально пытается выполнить ODB transaction.

## 15. Что было проверено

В текущем окружении проверено:

```text
cmake configure: OK
cmake build: OK
ODB generation into build/generated: OK
ctest: OK
--version: OK
GET /health: OK, 200 {"status":"ok"}
```

`POST /users` с реальной записью в PostgreSQL требует запущенную PostgreSQL БД и примененную схему. Код endpoint-а использует настоящий ODB/PostgreSQL путь, но без поднятой БД успешная запись невозможна.

## 16. Как сделать сервер многопоточным

Сейчас сервер однопоточный. Это видно по текущей форме `Server::run()`:

```cpp
for (;;) {
  tcp::socket socket{io};
  acceptor.accept(socket);

  boost::beast::flat_buffer buffer;
  BeastRequest request;
  http::read(socket, buffer, request);

  BeastResponse response = dispatcher.dispatch(request);
  http::write(socket, response);
}
```

Здесь все выполняется последовательно:

```text
1. Принять одно соединение.
2. Прочитать один HTTP request.
3. Обработать request.
4. Отправить response.
5. Только потом принять следующее соединение.
```

Если `POST /users` долго ждет PostgreSQL, то в это время даже `/health` будет ждать. Для учебного сервера это нормально, но для настоящего сервера нужен параллелизм.

### 16.1. Самый простой вариант: поток на каждое соединение

Идея:

```text
main thread
  -> accept socket
  -> start std::thread for this socket
  -> immediately go back to accept next socket
```

Пример формы кода:

```cpp
int Server::run(unsigned short port) {
  namespace asio = boost::asio;
  using tcp = asio::ip::tcp;

  asio::io_context io;
  tcp::acceptor acceptor{io, {tcp::v4(), port}};

  for (;;) {
    tcp::socket socket{io};
    acceptor.accept(socket);

    std::thread{
        [this](tcp::socket socket) mutable {
          RequestDispatcher dispatcher{router_};
          handle_connection(std::move(socket), dispatcher);
        },
        std::move(socket)}
        .detach();
  }
}
```

Смысл синтаксиса:

```cpp
std::thread{...}.detach();
```

создает новый поток и отделяет его от текущего. После `detach()` поток живет сам. Главный поток не ждет его завершения.

```cpp
[this](tcp::socket socket) mutable { ... }
```

это lambda. Она захватывает `this`, чтобы иметь доступ к `router_`, и принимает socket по значению. `mutable` нужно, потому что `tcp::socket` будет перемещаться и изменяться внутри lambda.

```cpp
std::move(socket)
```

передает владение сокетом в поток. Сокет нельзя копировать, потому что он владеет системным ресурсом.

Минусы такого варианта:

```text
1. На каждое соединение создается отдельный поток.
2. При большом количестве клиентов можно создать слишком много потоков.
3. detach усложняет аккуратное завершение сервера.
4. Это простой учебный путь, но не лучший production-путь.
```

### 16.2. Более правильный вариант: пул потоков + async Boost.Asio

Правильная модель для Beast/Asio обычно такая:

```text
io_context
  -> async_accept
  -> session per connection
  -> async_read
  -> dispatch request
  -> async_write
  -> several threads call io_context.run()
```

В этом подходе потоки не создаются на каждый request. Вместо этого создается фиксированный пул:

```cpp
const auto thread_count = std::max(1u, std::thread::hardware_concurrency());

std::vector<std::thread> threads;
threads.reserve(thread_count);

for (unsigned i = 0; i < thread_count; ++i) {
  threads.emplace_back([&io] {
    io.run();
  });
}

for (auto& thread : threads) {
  thread.join();
}
```

Смысл синтаксиса:

```cpp
std::thread::hardware_concurrency()
```

возвращает примерное количество аппаратных потоков CPU. Это не строгое правило, но хороший старт.

```cpp
threads.reserve(thread_count);
```

заранее выделяет память под вектор потоков, чтобы `vector` не перевыделял память при `emplace_back`.

```cpp
threads.emplace_back([&io] { io.run(); });
```

создает поток прямо внутри `vector`. Lambda захватывает `io` по ссылке, потому что все worker-потоки должны обслуживать один общий `io_context`.

```cpp
thread.join();
```

ждет завершения потока. В отличие от `detach`, такой поток контролируемый.

### 16.3. Почему нельзя просто вызвать `io.run()` в нескольких потоках в текущем коде

В текущем коде используются блокирующие операции:

```cpp
acceptor.accept(socket);
http::read(socket, buffer, request);
http::write(socket, response);
```

Они не ставят операции в очередь `io_context`. Они просто блокируют текущий поток до завершения операции. Поэтому такой код не станет нормальным async-сервером от добавления нескольких `io.run()`.

Чтобы пул потоков Asio имел смысл, операции должны быть асинхронными:

```cpp
acceptor.async_accept(...);
http::async_read(...);
http::async_write(...);
```

Тогда `io_context` получает работу, а worker-потоки могут эту работу выполнять.

### 16.4. Что нужно добавить для async-сервера

Обычно добавляют два класса:

```text
server/core/listener.hpp
server/core/listener.cpp
server/core/session.hpp
server/core/session.cpp
```

`Listener` отвечает только за прием соединений:

```text
bind/listen
async_accept
create Session for each socket
start next async_accept
```

`Session` отвечает за жизнь одного клиента:

```text
socket
flat_buffer
BeastRequest
RequestDispatcher
async_read
dispatch
async_write
close/keep-alive
```

Примерная структура:

```cpp
class Session : public std::enable_shared_from_this<Session> {
public:
  Session(tcp::socket socket, AppRouter& router);

  void run();

private:
  void read_request();
  void on_read(boost::beast::error_code ec, std::size_t bytes);
  void write_response(BeastResponse response);
  void on_write(boost::beast::error_code ec, std::size_t bytes);

  tcp::socket socket_;
  boost::beast::flat_buffer buffer_;
  BeastRequest request_;
  AppRouter& router_;
};
```

Почему `std::enable_shared_from_this`:

```text
Асинхронная операция может завершиться позже, чем функция, которая ее запустила.
Объект Session должен жить до завершения async_read/async_write.
shared_from_this() позволяет lambda-handler держать Session живой.
```

Типичный паттерн:

```cpp
auto self = shared_from_this();
http::async_read(socket_, buffer_, request_,
    [self](boost::beast::error_code ec, std::size_t bytes) {
      self->on_read(ec, bytes);
    });
```

Смысл:

```text
self хранит shared_ptr на текущую Session.
Пока callback не выполнится, Session не будет уничтожена.
```

### 16.5. Потокобезопасность текущих слоев

После включения многопоточности несколько request-ов могут одновременно попасть в:

```text
Handling
HTTP Controller
Application Controller
Database layer / ODB
```

Что важно:

```text
1. AppRouter после старта сервера только читается.
2. Если маршруты больше не добавляются после run(), читать router_ из разных потоков безопасно.
3. HttpRequest и HttpResponse создаются на один request, они не разделяются между потоками.
4. DTO и View тоже локальные для одного request.
5. Опасность начинается там, где есть общее состояние.
```

В текущей схеме общее состояние - это `UserController`, который хранит:

```cpp
fasc::server::database::Database& db_;
```

Внутри `Database` хранится `odb::database`. ODB database object обычно рассчитан на использование из разных потоков, но одна `odb::transaction` должна жить в одном потоке и не должна разделяться между request-ами. Поэтому правильно, что transaction создается внутри метода или через `invokeTransactionally`:

```cpp
db_.invokeTransactionally([&] {
  db_.persist(user);
});
```

Это локальная транзакционная область конкретного request-а.

Нельзя делать так:

```cpp
class UserController {
  odb::transaction tx_; // плохо
};
```

Потому что тогда transaction стала бы общим состоянием controller-а.

### 16.6. Что выбрать в этом учебном проекте

Для быстрого понимания можно сначала сделать `thread per connection`. Это проще и хорошо показывает саму идею параллельной обработки.

Для правильной архитектуры Boost.Beast лучше идти к async-варианту:

```text
Server
  -> Listener
  -> Session
  -> RequestDispatcher
  -> AppRouter
  -> Handling
  -> HTTP Controller
  -> Application Controller
  -> ODB/PostgreSQL
```

Тогда `Server::run()` будет только настраивать `io_context`, запускать `Listener` и поднимать пул потоков.

## 17. Подробно про CMake в этом проекте

CMakeLists.txt - это описание того, как собрать проект. Он не компилирует сам по себе. Он генерирует файлы для выбранной системы сборки, например Ninja.

Команда:

```powershell
cmake -S server -B server\build -G Ninja -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug
```

означает:

```text
-S server
  исходники CMake находятся в папке server

-B server\build
  build directory будет server/build

-G Ninja
  CMake должен сгенерировать файлы сборки для Ninja

-DCMAKE_CXX_COMPILER=clang++
  переменная CMake: использовать clang++ как C++ compiler

-DCMAKE_BUILD_TYPE=Debug
  собрать Debug-конфигурацию
```

### 17.1. Минимальная версия

```cmake
cmake_minimum_required(VERSION 3.25)
```

Это защита от слишком старого CMake. Если версия ниже 3.25, CMake остановится. Так проект не будет случайно собираться инструментом, который не понимает нужный синтаксис.

### 17.2. Объявление проекта

```cmake
project(farm_association_server VERSION 0.1.0 LANGUAGES CXX)
```

Смысл:

```text
farm_association_server
  имя проекта

VERSION 0.1.0
  версия проекта

LANGUAGES CXX
  проект использует C++
```

### 17.3. Стандарт C++

```cmake
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
```

Что это значит:

```text
CMAKE_CXX_STANDARD 20
  просим C++20

CMAKE_CXX_STANDARD_REQUIRED ON
  если C++20 недоступен, CMake должен упасть, а не молча выбрать старый стандарт

CMAKE_CXX_EXTENSIONS OFF
  использовать стандартный C++20, а не compiler-specific расширения вроде gnu++20
```

### 17.4. Options

```cmake
option(FARM_SERVER_WITH_ODB "Build with ODB PostgreSQL support" ON)
```

`option` создает boolean-переменную, которую можно менять из командной строки:

```powershell
cmake -S server -B server\build -DFARM_SERVER_WITH_ODB=OFF
```

Зачем это нужно:

```text
Можно временно отключить тяжелую зависимость.
Можно собрать проект в окружении без PostgreSQL/ODB.
Можно явно управлять вариантом сборки.
```

### 17.5. Cache path

```cmake
set(FARM_SERVER_DEPS_DIR
    "${CMAKE_CURRENT_SOURCE_DIR}/third_party"
    CACHE PATH "Directory with local project dependencies")
```

Обычный `set()` живет только внутри текущей конфигурации CMake. `CACHE PATH` сохраняет значение в `CMakeCache.txt`, и пользователь может переопределить его:

```powershell
cmake -S server -B server\build -DFARM_SERVER_DEPS_DIR=D:\libs\farm
```

`CMAKE_CURRENT_SOURCE_DIR` - это папка, где находится текущий `CMakeLists.txt`. В нашем случае это `server`.

### 17.6. Module path и include

```cmake
list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/cmake")
include(FarmLocalDependencies)
```

`CMAKE_MODULE_PATH` - список папок, где CMake ищет дополнительные `.cmake`-файлы.

`include(FarmLocalDependencies)` загружает файл:

```text
server/cmake/FarmLocalDependencies.cmake
```

После этого в `CMakeLists.txt` становятся доступны функции:

```cmake
farm_add_boost_headers(...)
farm_add_nlohmann_json(...)
farm_add_fmt(...)
farm_add_odb_local_build(...)
```

Почему зависимости вынесены туда:

```text
Основной CMakeLists.txt остается про сборку сервера.
FarmLocalDependencies.cmake содержит детали поиска локальных библиотек.
Так проще читать проект.
```

### 17.7. find_package Threads

```cmake
find_package(Threads REQUIRED)
```

Это просит CMake найти поддержку потоков. На Windows это может быть одно, на Linux другое. После успешного поиска появляется target:

```cmake
Threads::Threads
```

Его подключают так:

```cmake
target_link_libraries(farm_association_server PRIVATE Threads::Threads)
```

Если сервер станет многопоточным через `std::thread` или Asio thread pool, эта зависимость уже нужна.

### 17.8. add_executable и target_sources

```cmake
add_executable(farm_association_server)
```

создает цель сборки. Цель - это не файл прямо сейчас, а объект CMake, к которому дальше добавляют исходники, include dirs, libraries и compile definitions.

```cmake
target_sources(farm_association_server
    PRIVATE
        src/main.cpp
        src/controllers/app/Users.cpp
        ...)
```

`target_sources` добавляет `.cpp` файлы к executable.

`PRIVATE` значит:

```text
Эти исходники нужны только самой цели farm_association_server.
Они не становятся частью публичного интерфейса для других целей.
```

### 17.9. Include directories

```cmake
target_include_directories(farm_association_server
    PRIVATE
        "${FARM_SERVER_GENERATED_DIR}"
        "${CMAKE_CURRENT_SOURCE_DIR}/include/persistence"
        "${CMAKE_CURRENT_SOURCE_DIR}/include")
```

Это добавляет пути для `#include`.

Почему нужны именно эти пути:

```text
${CMAKE_CURRENT_SOURCE_DIR}/include
  чтобы работали include вроде <controllers/app/Users.hpp>

${FARM_SERVER_GENERATED_DIR}
  чтобы работали include вроде <persistence/user-odb.hxx>

${CMAKE_CURRENT_SOURCE_DIR}/include/persistence
  потому что сгенерированный user-odb.hxx включает исходный user.hpp как "user.hpp"
```

### 17.10. target_link_libraries

```cmake
target_link_libraries(farm_association_server
    PRIVATE
        Threads::Threads
        farm_boost
        farm_nlohmann_json
        farm_fmt)
```

Это подключает библиотеки к цели.

Современный CMake предпочитает targets вместо сырых путей:

```text
farm_fmt
  не просто путь к .lib/.a
  а CMake target, который может нести include dirs, compile definitions и link settings
```

### 17.11. Windows-specific блок

```cmake
if(WIN32)
    target_compile_definitions(farm_association_server PRIVATE _WIN32_WINNT=0x0601)
    target_link_libraries(farm_association_server PRIVATE ws2_32 mswsock)
endif()
```

`WIN32` - встроенная CMake-переменная. Она true на Windows.

`_WIN32_WINNT=0x0601` говорит Windows headers, какую минимальную версию Windows API разрешено использовать. `0x0601` соответствует Windows 7. Boost.Asio часто требует эту define на Windows.

`ws2_32` и `mswsock` - системные Windows-библиотеки для socket API. Boost.Asio использует сокеты, поэтому они нужны при линковке.

### 17.12. add_custom_command для ODB

```cmake
add_custom_command(
    OUTPUT
        "${FARM_SERVER_USER_ODB_CXX}"
        "${FARM_SERVER_USER_ODB_HXX}"
        "${FARM_SERVER_USER_ODB_IXX}"
        "${FARM_SERVER_USER_SQL}"
    COMMAND "${CMAKE_COMMAND}" -E make_directory "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}"
    COMMAND "${FARM_SERVER_ODB_COMPILER}"
        --std c++14
        --database pgsql
        --generate-query
        --generate-schema
        --output-dir "${FARM_SERVER_GENERATED_PERSISTENCE_DIR}"
        "${FARM_SERVER_USER_MODEL}"
    DEPENDS
        "${FARM_SERVER_USER_MODEL}"
        "${FARM_SERVER_ODB_COMPILER}"
    COMMENT "Generating ODB mapping for persistence/User.hpp"
    VERBATIM)
```

Смысл:

```text
OUTPUT
  какие файлы появятся после команды

COMMAND
  какие команды надо выполнить

DEPENDS
  от чего зависит генерация

COMMENT
  текст для вывода во время сборки

VERBATIM
  CMake должен аккуратно экранировать пути и аргументы
```

Почему ODB запускается только когда надо:

```text
CMake/Ninja видит OUTPUT и DEPENDS.
Если user.hpp не менялся и output-файлы уже есть, генерацию можно не повторять.
Если user.hpp изменился, Ninja снова запустит odb.exe.
```

### 17.13. GENERATED property

```cmake
set_source_files_properties(
    "${FARM_SERVER_USER_ODB_CXX}"
    "${FARM_SERVER_USER_ODB_HXX}"
    "${FARM_SERVER_USER_ODB_IXX}"
    "${FARM_SERVER_USER_SQL}"
    PROPERTIES GENERATED TRUE)
```

Это сообщает CMake:

```text
Этих файлов может не быть на момент configure.
Они появятся во время build.
Не надо ругаться, что файл пока отсутствует.
```

### 17.14. Imported libraries

В проекте ODB и PostgreSQL превращаются в CMake targets:

```cmake
farm_add_imported_library(ODB::odb "${ODB_LIBRARY}" "${ODB_INCLUDE_DIR}")
farm_add_imported_library(ODB::pgsql "${ODB_PGSQL_LIBRARY}" "${ODB_PGSQL_INCLUDE_DIR}")
farm_add_imported_library(PostgreSQL::pq "${POSTGRESQL_LIBRARY}" "${POSTGRESQL_INCLUDE_DIR}")
```

И потом подключаются:

```cmake
target_link_libraries(farm_association_server PRIVATE ODB::odb ODB::pgsql PostgreSQL::pq)
```

Плюс такого подхода:

```text
Цель ODB::odb знает и путь к библиотеке, и путь к headers.
Основной target_link_libraries выглядит чисто.
Проект меньше зависит от конкретной структуры папок.
```

### 17.15. Compile definitions для ODB

```cmake
target_compile_definitions(farm_association_server
    PRIVATE
        LIBODB_STATIC_LIB
        LIBODB_PGSQL_STATIC_LIB
        _HAS_AUTO_PTR_ETC=1
        _CRT_SECURE_NO_WARNINGS)
```

Зачем:

```text
LIBODB_STATIC_LIB
  говорим headers libodb, что линкуемся со static library

LIBODB_PGSQL_STATIC_LIB
  то же самое для libodb-pgsql

_HAS_AUTO_PTR_ETC=1
  включает старые совместимые типы в MSVC STL, потому что ODB 2.4.0 использует std::auto_ptr

_CRT_SECURE_NO_WARNINGS
  отключает MSVC warnings про старые C-функции
```

### 17.16. POST_BUILD copy

```cmake
add_custom_command(TARGET farm_association_server POST_BUILD
    COMMAND "${CMAKE_COMMAND}" -E copy_directory
        "${FARM_SERVER_DEPS_DIR}/postgresql/bin"
        "$<TARGET_FILE_DIR:farm_association_server>"
    COMMENT "Copying PostgreSQL runtime DLLs"
    VERBATIM)
```

Это команда, которая выполняется после линковки `farm_association_server`.

`$<TARGET_FILE_DIR:farm_association_server>` - generator expression. Во время генерации build files CMake подставит туда папку, где лежит `.exe`.

На Windows это нужно, потому что `.exe` должен найти runtime DLLs PostgreSQL рядом с собой или через `PATH`.

## 18. Подробно про ODB syntax

ODB - это ORM для C++. Он читает C++ классы с `#pragma db`, генерирует C++ mapping-код и SQL-схему.

Исходный persistence object:

```cpp
#pragma once

#include <odb/core.hxx>

#include <string>

#pragma db object
class User {
public:
  User() = default;
  explicit User(std::string name) : name_(std::move(name)) {}

  unsigned long id() const { return id_; }
  const std::string& name() const { return name_; }

private:
  friend class odb::access;

#pragma db id auto
  unsigned long id_{};

  std::string name_;
};
```

### 18.1. `#include <odb/core.hxx>`

Этот header нужен для базовых объявлений ODB, включая `odb::access` и поддержку pragmas.

Без него компилятор не будет знать, что такое:

```cpp
friend class odb::access;
```

### 18.2. `#pragma db object`

```cpp
#pragma db object
class User {
```

Эта pragma говорит ODB compiler:

```text
User - persistent class.
Для него надо сгенерировать mapping.
Для него нужна таблица в БД.
```

Обычный C++ compiler эту pragma либо игнорирует, либо пропускает как compiler-specific директиву. А `odb.exe` читает ее и понимает.

### 18.3. `#pragma db id auto`

```cpp
#pragma db id auto
unsigned long id_{};
```

Смысл:

```text
id
  это primary key объекта

auto
  значение генерирует база данных
```

Для PostgreSQL ODB обычно сгенерирует SQL с автоинкрементным идентификатором.

Почему поле private:

```text
Внешний код не должен сам менять id.
id назначает база.
Код читает id через метод id().
```

### 18.4. `friend class odb::access`

```cpp
friend class odb::access;
```

Поля `id_` и `name_` private. Это хорошо для инкапсуляции, но ODB должен уметь читать и записывать эти поля при загрузке из БД.

`friend class odb::access` разрешает ODB-доступ к private-полям, не открывая их всему приложению.

### 18.5. Default constructor

```cpp
User() = default;
```

ODB нужен конструктор без параметров, чтобы создать объект при чтении строки из БД, а потом заполнить поля.

Обычный код приложения может использовать удобный constructor:

```cpp
explicit User(std::string name) : name_(std::move(name)) {}
```

`explicit` запрещает случайные неявные преобразования:

```cpp
User user = "Alice"; // explicit не позволит так сделать
User user{"Alice"};  // правильно
```

### 18.6. Почему getters, а не public fields

```cpp
unsigned long id() const { return id_; }
const std::string& name() const { return name_; }
```

Так внешний код может читать данные, но не может случайно нарушить состояние объекта:

```text
id_ нельзя поменять вручную.
name_ нельзя поменять без отдельного метода, где можно добавить проверки.
```

### 18.7. Сгенерированные файлы

После запуска ODB появляются:

```text
user-odb.hxx
user-odb.ixx
user-odb.cxx
user.sql
```

Смысл:

```text
user-odb.hxx
  declarations generated by ODB

user-odb.ixx
  inline implementation generated by ODB

user-odb.cxx
  compiled implementation: persist/load/query logic

user.sql
  SQL schema for PostgreSQL
```

Поэтому application controller включает:

```cpp
#include <persistence/User.hpp>
#include <persistence/user-odb.hxx>
```

`user.hpp` нужен для самого класса `User`.  
`user-odb.hxx` нужен, чтобы ODB-зависимые операции знали mapping этого класса.

### 18.8. Transaction syntax

```cpp
db_.invokeTransactionally([&] {
  db_.persist(user);
});
```

`invokeTransactionally` открывает транзакцию, если ее еще нет в текущем потоке, выполняет callback и делает `commit()` после успешного выполнения. Если callback бросит исключение, `commit()` не вызывается, объект `Transaction` уничтожается, а ODB откатывает незавершенную транзакцию.

```cpp
db_.persist(user);
```

говорит database layer сохранить новый объект в БД через ODB. После `persist` ODB может заполнить auto id:

```cpp
user.id()
```

Ручной вариант тоже возможен:

```cpp
auto tx = db_.makeTransaction();
db_.persist(user);
tx.commit();
```

Если `makeTransaction()` вызывается повторно внутри уже активной транзакции на той же `Database`, вложенный `Transaction` не владеет реальной ODB-транзакцией. Его `commit()`, `rollback()` и деструктор не закрывают внешнюю транзакцию.

Почему transaction локальная:

```text
Каждый request получает свою transaction.
Это важно для многопоточности.
Нельзя хранить transaction как поле controller-а.
```

### 18.9. Почему persistence не содержит бизнес-логику

Persistence object отвечает за форму данных, которую понимает ODB:

```text
fields
constructors
getters
ODB pragmas
```

Бизнес-логика лежит в application controller:

```text
проверки
правила создания
решение, когда persist/load/update/delete
transaction boundary
```

Так `User` остается моделью хранения, а `UserController` управляет поведением приложения.

## 19. Подробно про поток запроса

Для `POST /users` путь такой:

```text
Boost.Beast request
  -> RequestDispatcher
  -> HttpRequest
  -> AppRouter
  -> UserHandler
  -> UserHttpController
  -> CreateUserCommand
  -> UserController
  -> User persistence object
  -> ODB transaction
  -> PostgreSQL
  -> UserDto
  -> UserView
  -> HttpResponse
  -> BeastResponse
```

Почему именно так:

```text
RequestDispatcher
  изолирует Boost.Beast

AppRouter
  выбирает endpoint по method + path

Handling
  связывает endpoint с конкретным HTTP controller

HTTP Controller
  знает про HTTP, JSON, status codes и views

Application Controller
  знает про бизнес-логику и persistence

Persistence object
  знает про ODB mapping

Database layer
  знает, как создать подключение к PostgreSQL
```

Если где-то нарушить эту границу, код быстро смешается. Например, если `UserController` начнет возвращать JSON, он станет зависеть от HTTP-представления. Если `UserHandler` начнет работать с `UserDto`, он начнет знать детали бизнес-слоя. Поэтому каждый слой держит только свою ответственность.
