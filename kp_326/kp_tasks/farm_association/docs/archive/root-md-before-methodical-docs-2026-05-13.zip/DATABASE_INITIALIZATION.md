﻿# Инициализация базы данных

Этот документ описывает текущее устройство database layer в проекте: где создается подключение к PostgreSQL, как оно попадает в application controller и как открываются транзакции.

## Короткая цепочка

```text
main.cpp
  -> fasc::server::database::Database::createFromEnv()
  -> odb::pgsql::database
  -> UserController
  -> Database::invokeTransactionally()
  -> Database::persist/update/erase
```

`Database` - это проектная обертка над `odb::database`. Внешний код не создает `odb::pgsql::database` напрямую и не должен размазывать детали PostgreSQL по controller-ам.

## Где создается Database

В `server/src/main.cpp` база создается один раз при старте приложения:

```cpp
auto database = fasc::server::database::Database::createFromEnv();

UserController user_controller{database};
```

`database` живет до конца `main()`, поэтому все controller-ы получают стабильную ссылку на один объект database layer.

## Откуда берутся параметры подключения

`Database::createFromEnv()` реализован в `server/src/database/database.cpp`. Он читает переменные окружения и, если они не заданы, использует значения по умолчанию:

```text
FARM_DB_USER      postgres
FARM_DB_PASSWORD  password
FARM_DB_NAME      farm_association
FARM_DB_HOST      localhost
FARM_DB_PORT      5432
```

Пример настройки в PowerShell:

```powershell
$env:FARM_DB_USER = "postgres"
$env:FARM_DB_PASSWORD = "password"
$env:FARM_DB_NAME = "farm_association"
$env:FARM_DB_HOST = "localhost"
$env:FARM_DB_PORT = "5432"
```

После чтения настроек создается реальный ODB-объект:

```cpp
std::make_unique<odb::pgsql::database>(user, password, db, host, port)
```

Этот объект хранится внутри `fasc::server::database::Database`.

## Что делает Database

`server/include/database/database.hpp` содержит:

```cpp
class Database {
public:
  static Database createFromEnv();

  Transaction makeTransaction();
  bool hasActiveTransaction() const;

  template <typename Work>
  decltype(auto) invokeTransactionally(Work&& work);

  template <typename Entity>
  auto persist(Entity& entity);

  template <typename Entity>
  void update(Entity& entity);

  template <typename Entity>
  void erase(Entity& entity);

  template <typename Entity, typename Id>
  bool eraseById(const Id& id);
};
```

Смысл этого слоя:

```text
createFromEnv()
  собирает подключение из переменных окружения

makeTransaction()
  открывает ручную транзакцию или присоединяется к уже активной

invokeTransactionally()
  выполняет блок кода внутри транзакции

persist/update/erase/eraseById()
  дают короткие обертки над ODB-операциями
```

Если нужен доступ к сырому ODB-объекту для редкого низкоуровневого сценария, есть `raw()`. Обычный application code должен пользоваться обертками.

## Транзакции

Основной рекомендуемый способ:

```cpp
return db_.invokeTransactionally([&] {
  User user{std::move(command.name)};
  db_.persist(user);

  return UserDto{user.id(), user.name()};
});
```

Поведение:

```text
Если активной транзакции нет
  Database открывает новую Transaction, выполняет callback и делает commit.

Если callback бросает исключение
  commit не вызывается, Transaction уничтожается, ODB откатывает транзакцию.

Если активная транзакция уже есть на этой же Database
  новая транзакция не открывается, callback выполняется внутри внешней транзакции.

Если активная транзакция есть на другой Database в этом же потоке
  бросается odb::already_in_transaction.
```

Ручной вариант тоже поддержан:

```cpp
auto tx = db.makeTransaction();
db.persist(user);
tx.commit();
```

Если внутри уже есть активная транзакция на той же базе:

```cpp
auto outer = db.makeTransaction();
auto inner = db.makeTransaction();

inner.commit(); // no-op
outer.commit(); // реальный commit
```

Вложенный `Transaction` в этом случае не владеет реальной ODB-транзакцией, поэтому его `commit()`, `rollback()` и деструктор не закрывают внешнюю транзакцию.

## Почему не передаем odb::database в controller

Раньше application controller мог работать напрямую с `odb::database`:

```cpp
odb::transaction tx(db_.begin());
db_.persist(user);
tx.commit();
```

Сейчас controller получает `fasc::server::database::Database&`. Так application layer не знает деталей открытия PostgreSQL-подключения и не дублирует транзакционный шаблон.

Это оставляет границы такими:

```text
HTTP controller
  JSON, HTTP status, HttpResponse

View
  public resource representation without HTTP metadata

Application controller
  бизнес-правила, DTO, persistence objects

Database layer
  ODB connection, transactions, persist/update/erase

Persistence objects
  ODB pragmas and storage shape
```

## Что не делает инициализация

`Database::createFromEnv()` не создает базу данных PostgreSQL и не применяет SQL-схему. Он только создает client connection object.

SQL-схема генерируется ODB compiler-ом при сборке:

```text
server/build/generated/persistence/user.sql
```

Эту схему нужно применить к PostgreSQL отдельно, если база еще не подготовлена.
